//
//  Utilities.h
//  nBlue
//
//  Created by Michael Testa on 3/7/12.
//  Copyright (c) 2012 BlueRadios, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

//Some common static utility functions that are used internally throughout the library
@interface Util : NSObject
+ (NSString*)osVersion;
+ (BOOL)isAtLeastVersion:(NSString*)version;

+ (CBService*)findService:(CBUUID*)uuid InPeripheral:(CBPeripheral*)peripheral;
+ (CBCharacteristic*) findCharacteristic:(CBUUID *)uuid InService:(CBService*)service;

//+ (const char *) UUIDRefToString:(CFUUIDRef)UUID;
+ (NSString*) UUIDRefToNSString:(CFUUIDRef)uuidref;

//Returns true if state = CBPeripheralStateConnecting or CBPeripheralStateConnected
+ (BOOL) isConnected:(CBPeripheral*)peripheral;


@end
