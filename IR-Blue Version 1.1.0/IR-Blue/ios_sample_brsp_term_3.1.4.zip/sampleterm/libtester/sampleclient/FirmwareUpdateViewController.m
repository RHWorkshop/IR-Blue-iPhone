//
//  FirmwareUpdateViewController.m
//  sampleterm
//
//  Created by Neel Pansare on 5/20/14.
//
//

#import "FirmwareUpdateViewController.h"
#import "TWRProgressView.h"
#import "BRLightMeter.h"
#import "STConstants.h"
#import "MBProgressHUD.h"
#import "BrspManager.h"

@interface FirmwareUpdateViewController ()

@property (nonatomic, strong) MBProgressHUD *mbProgressHUD;
@property (nonatomic) float totalFirmwareUpdateData;
@property (nonatomic) BOOL isUpdateInProgress;
@property (nonatomic, weak) IBOutlet TWRProgressView *progressView;
@property (nonatomic, strong) BRLightMeter *progressMeter;
@property (nonatomic, strong) NSTimer *updateProgressTimer;
@property (nonatomic, strong) NSTimer *connectionTimer;
@property (nonatomic) BOOL didUpdateSucceed;
@property (nonatomic) BOOL isFirmwareUpdateSpeedupRequest;
@property (nonatomic) BOOL isResettingDevice;
@end

@implementation FirmwareUpdateViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationItem.title = @"Firmware Update";
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStyleBordered target:self action:@selector(backBarButtonTapped:)];
    self.navigationController.interactivePopGestureRecognizer.delegate = nil;
    
    _lblFirmwareUpdateFileName.text = _firmwareUpdateFileName;
    
    [self setupProgressView];
    
    // timer init
    _updateProgressTimer = [[NSTimer alloc] init];

    [_btnUpdate setEnabled:YES];
}

- (void) viewDidAppear:(BOOL)animated {
    
    [AppDelegate app].cbCentral.delegate = self;
    _isResettingDevice = NO;
    [self setupViewController];
}

- (void) viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark CBCentralManagerDelegate
- (void)centralManagerDidUpdateState:(CBCentralManager *)central {
    
}

- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral {
    
    [_connectionTimer invalidate];
    _mbProgressHUD.labelText = @"Connected.";
}

- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    
    [_updateProgressTimer invalidate];
    [MBProgressHUD hideHUDForView:self.view animated:YES];
    
    if (_didUpdateSucceed) {
        
        [self.navigationController popToRootViewControllerAnimated:YES];
    } else if (_isResettingDevice) {
        
        [self.navigationController popToRootViewControllerAnimated:YES];
    } else {
        
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark BrspManager Delegate Methods


- (void) brsp:(Brsp*)brsp openStatusChanged:(BOOL)isOpen {
    
    if (isOpen) {
        
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        NSLog(@"BRSP open with Security Level: %lu", (unsigned long)[BrspManager sharedInstance].brspObject.securityLevel);
    }
}

- (void) brspModeChanged:(Brsp*)brsp BRSPMode:(BrspMode)mode {
    
    switch (mode) {
        case BrspModeData:
            
            NSLog(@"@@@ Mode Changed to Data.");
            break;
        case BrspModeRemoteCommand:
            
            NSLog(@"@@@ Mode Changed to RemoteCommand.");
            
            if (_isFirmwareUpdateSpeedupRequest) {
                
                // Send command to speed up Firmware Update
                [self sendCommand:kATSCCPCommand];
            } else {
                
                // Reset the currently installed firmware
                _isResettingDevice = YES;
                [self sendCommand:kATRSTCommand];
            }
            
            break;
            
        case BrspModeFirmwareUpdate:
            
            NSLog(@"@@@ Mode Changed to FirmwareUpdate.");
            [_mbProgressHUD hide:YES];
            [self beginUpdatingFirmware];
            break;
            
        default:
            
            NSLog(@"@@@ Mode Change Failed.");
            break;
    }
}

- (void) brsp:(Brsp*)brsp sendingStatusChanged:(BOOL)isSending {
    //This is a good place to change BRSP mode
    //If we are on the last command in the queue and we are no longer sending, change the mode back to previous value

}

// Data Received Call Back function gets called after writeBytes is executed successfully
- (void) brspDataReceived:(Brsp*)brsp {
    
    if (_isFirmwareUpdateSpeedupRequest) {
        
        _isFirmwareUpdateSpeedupRequest = NO;
        [[BrspManager sharedInstance].brspObject changeBrspMode:BrspModeFirmwareUpdate];
    }
    
    // If the sent request was a remote command return
    if ([BrspManager sharedInstance].brspObject.brspMode == BrspModeRemoteCommand) {

        return;
    }
    
    // If send request was Firmware update related then proceed to firmware update calls
    [self setUpdateTimer];
    
    if ([BrspManager sharedInstance].brspObject == nil && [BrspManager sharedInstance].brspObject.delegate == nil) {
        return;
    }
    _isUpdateInProgress = NO;
    
    NSData *tempData = [brsp readBytes:1];
    NSString *returnedValueStar = @"*";
    NSString *returnedValueZero = @"0";
    NSString *returnedValueOne = @"1";
    NSString *confirmFirmwareInstruction = @"1";
    NSString *applyFirmwareInstruction = @"0";
    
    if ([tempData isEqualToData:[returnedValueStar dataUsingEncoding:NSUTF8StringEncoding]]) {
        
        if (_firmwareUpdateData.count > 0) {
            
            _isUpdateInProgress = YES;
            
            if (_firmwareUpdateData.count > 0) {
                
                //Send the next data
                NSString *nextDataString = [_firmwareUpdateData objectAtIndex:0];
                NSData *nextData = [self dataFromHexString :nextDataString];
                [[BrspManager sharedInstance].brspObject writeBytes:nextData];
                [_firmwareUpdateData removeObjectAtIndex:0]; //Remove last sent command from our queue array
                
                int progressInt = _totalFirmwareUpdateData - [_firmwareUpdateData count];
                NSNumber *progressNumber = [NSNumber numberWithInt:progressInt];
                
                [self updateProgress:progressNumber fileSize:[NSNumber numberWithFloat:_totalFirmwareUpdateData]];
            }
        }
        else {
            
            _isUpdateInProgress = YES;
            NSData *nextData = [confirmFirmwareInstruction dataUsingEncoding:NSUTF8StringEncoding];
            [[BrspManager sharedInstance].brspObject writeBytes:nextData];
        }
    } else if([tempData isEqualToData:[returnedValueOne dataUsingEncoding:NSUTF8StringEncoding]]) {
        
        _isUpdateInProgress = NO;
        
        NSData *nextData = [applyFirmwareInstruction dataUsingEncoding:NSUTF8StringEncoding];
        [[BrspManager sharedInstance].brspObject writeBytes:nextData];
        
        _didUpdateSucceed = YES;
        
        [_updateProgressTimer invalidate];
        [self showAlertUpdateSucceeded];
    } else if([tempData isEqualToData:[returnedValueZero dataUsingEncoding:NSUTF8StringEncoding]]) {
        
        _isUpdateInProgress = NO;
        [_btnUpdate setEnabled:YES];
        [_lblPercentage setText:@"--"];
        [_updateProgressTimer invalidate];
        [self showAlertUpdateFailed];
    }
}

#pragma mark - Instance Methods

- (void) setupViewController {
    
    //It is important to set this delegate before calling [Brsp open]
    [BrspManager sharedInstance].delegate = self;
    
    // If BRSP object is not open for communication - Open
    _mbProgressHUD.labelText = @"Preparing to update...";
    if (![[BrspManager sharedInstance].brspObject isOpen]) {
        [[BrspManager sharedInstance].brspObject open];
    }
    
    _isUpdateInProgress = NO;
    _shouldFactoryResetAfterUpdate = NO;
    _isFirmwareUpdateSpeedupRequest = NO;
}

- (void)setupProgressView {
    
    UIImage *lockImage = [[UIImage imageNamed:@"update_firmware.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    self.progressView.maskingImage = lockImage;
    [self.progressView setFrontColor:STCCustomBlueColor];
    self.progressView.tintColor = [UIColor grayColor];
}

- (void)updateProgress:(NSNumber *)flashed fileSize:(NSNumber *)fileSize {
    
    float actual = [_progressMeter progress];
    if (actual < 1.0) {
        float percent = ((float)flashed.integerValue/(float)fileSize.integerValue);
        [self.progressView setProgress:percent];
        [self.progressMeter setProgress:percent];
        
        int rounded = (int) ((percent*100) + 0.5);
        
        if(rounded == 0){
            [self.lblPercentage setText:@"0%"];
        }else if (rounded == 100){
            [self.lblPercentage setText:@"100%"];
            
        }else if(rounded != 0){
            NSString *percentString = [NSString stringWithFormat:@"%i%%", rounded];
            [self.lblPercentage setText:percentString];
        }
    }
}

- (void) connectPeripheral {
    
    _connectionTimer = [NSTimer scheduledTimerWithTimeInterval:(float)8.0 target:self selector:@selector(cancelConnectionTimout) userInfo:nil repeats:NO];
    
    _mbProgressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    _mbProgressHUD.labelText = @"Connecting...";
    
    [AppDelegate app].cbCentral.delegate = self;
    [[AppDelegate app].cbCentral connectPeripheral:[AppDelegate app].activePeripheral options:nil];
}


- (void)cancelConnectionTimout {
    NSLog(@"connectionTimeout reached.");
    [_connectionTimer invalidate];
    [NSTimer scheduledTimerWithTimeInterval:(float)2.0 target:self selector:@selector(disconnectTimer) userInfo:nil repeats:NO];
}

- (void)disconnectTimer {
    
    [self disconnectPeripheral];
}

- (void) disconnectPeripheral {
    
    [_mbProgressHUD show:YES];
    _mbProgressHUD.labelText = @"Disconnecting...";
    [[AppDelegate app].cbCentral cancelPeripheralConnection:[AppDelegate app].activePeripheral];
}

- (void)setUpdateTimer {
    
    [_updateProgressTimer invalidate];
    _updateProgressTimer = [NSTimer scheduledTimerWithTimeInterval:30.0 target:self selector:@selector(failedToConnect:) userInfo:nil repeats:NO];
}

- (void)failedToConnect:(NSTimer *) theTimer {
    
    [self showAlertDisconnectedDevice];
    [_updateProgressTimer invalidate];
}

- (void) prepareToUpdateFirmware {
    
    _isFirmwareUpdateSpeedupRequest = YES;
    
    // If BRSP object is not open for communication - Open
    if (![[BrspManager sharedInstance].brspObject isOpen]) {
        
        [self showAlertDisconnectedDevice];
        return;
    }
    
    if ([BrspManager sharedInstance].brspObject.brspMode == BrspModeRemoteCommand) {
        
        // Send command to speed up Firmware Update
        [self sendCommand:kATSCCPCommand];
    } else {
        [[BrspManager sharedInstance].brspObject changeBrspMode:BrspModeRemoteCommand];
    }
}

- (void) beginUpdatingFirmware {
    
    // Flush Input/Output buffers before using
    [[BrspManager sharedInstance].brspObject flushOutputBuffer];
    [[BrspManager sharedInstance].brspObject flushInputBuffer];
    
    // Update in process flag
    _isUpdateInProgress = YES;
    
    // Check for update timeouts
    [self setUpdateTimer];
    
    _firmwareUpdateData = [BrspManagerInstance.brspObject getOTAUpdateInstructionsFrom:self.firmwarePath shouldFactoryResetAfterSuccess:_shouldFactoryResetAfterUpdate];
    
    // Calculate Total count of data lines to be sent
    _totalFirmwareUpdateData = [_firmwareUpdateData count];
    
    if(_firmwareUpdateData.count > 0) {
        
        [self.lblPercentage setText:@"0%"];
        [[BrspManager sharedInstance].brspObject writeBytes:[_firmwareUpdateData objectAtIndex:0]];
        [_firmwareUpdateData removeObjectAtIndex:0];
        
    } else {
        
        [self showAlertFirmwareNotFound];
    }
}

// Get Data from Hex String
- (NSData *) dataFromHexString:(NSString *)string {
    string = [string lowercaseString];
    NSMutableData *data= [NSMutableData new];
    unsigned char whole_byte;
    char byte_chars[3] = {'\0','\0','\0'};
    int i = 0;
    UInt64 length = string.length;
    while (i < length-1) {
        char c = [string characterAtIndex:i++];
        if (c < '0' || (c > '9' && c < 'a') || c > 'f')
            continue;
        byte_chars[0] = c;
        byte_chars[1] = [string characterAtIndex:i++];
        whole_byte = strtol(byte_chars, NULL, 16);
        [data appendBytes:&whole_byte length:1];
        
    }
    
    return data;
}

#pragma mark - IBActions

- (void) backBarButtonTapped:(id)sender {
    if (_isUpdateInProgress) {
        
        [self showAlertHaltUpdate];
        
    } else {
        
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (IBAction)btnUpdateTapped:(id)sender {
    
    self.firmwarePath = [[NSBundle mainBundle] pathForResource:_firmwareUpdateFileName ofType:@"bru"];
    
    
    // Disable update button click
    [_btnUpdate setEnabled:NO];
    
    [self showAlertFactoryReset];
}

// NOTE: Workaround - this is a workaround for an issue in the firmware prior to 3.1.2.0
- (BOOL) isCurrentlyInstalledFirmwareErroneous {
    
    NSArray * erronousFirmwareFileNames = STCErroneousFirmwareFileNames;
    for (NSString *firmwareName in erronousFirmwareFileNames) {
        
        if ([_currentlyInstalledFirmware rangeOfString:firmwareName].location != NSNotFound) {
            
            return YES;
        }
        
    }
    
    return NO;
}

#pragma mark - UIAlertView Delegate Methods

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    
    switch (alertView.tag) {
        case kAlertFactoryReset:
            
            if (buttonIndex == 0) {
                
                _shouldFactoryResetAfterUpdate = YES;
                [self prepareToUpdateFirmware];
                
            } else {
                
                _shouldFactoryResetAfterUpdate = NO;
                [self prepareToUpdateFirmware];
            }
            
            break;
            
        case kAlertViewTagHaltUpdate:
            
            if (buttonIndex == 0){
                
                // NOTE: Workaround - this is a workaround for an issue in the firmware prior to 3.1.2.0
                if ([self isCurrentlyInstalledFirmwareErroneous]) {
                    
                    if ([[BrspManager sharedInstance].brspObject isOpen]) {
                        
                        if ([BrspManager sharedInstance].brspObject.isRemoteCommandModeSupported != YES) {
                            
                            [self showAlertResetDevice];
                            break;
                        } else if ([BrspManager sharedInstance].brspObject.brspMode == BrspModeFirmwareUpdate && [BrspManager sharedInstance].brspObject.isRemoteCommandModeSupported) {
                            
                            [[BrspManager sharedInstance].brspObject flushInputBuffer];
                            [[BrspManager sharedInstance].brspObject flushOutputBuffer];
                            [[BrspManager sharedInstance].brspObject changeBrspMode:BrspModeRemoteCommand];
                            break;
                        } else if ([BrspManager sharedInstance].brspObject.brspMode == BrspModeRemoteCommand) {
                            
                            // Reset the currently installed firmware
                            [self sendCommand:@"ATRST"];
                            break;
                        }
                    
                    }
                }
                
                [self disconnectPeripheral];
            }
            else if (buttonIndex == 1) {
                // Cancel Button - Do nothing
            }
            
            break;
            
        case kAlertViewDisconectedDevice:
            
            [self disconnectPeripheral];
            break;
            
        default:
            break;
    }
}


-(void) sendCommand:(NSString *) str {
    if (![[str substringFromIndex:str.length-1] isEqualToString:@"\r"])
        str = [NSString stringWithFormat:@"%@\r", str];  //Append a carriage return
    //Write as string
    NSError *writeError = [[BrspManager sharedInstance].brspObject writeString:str];
    if (writeError)
        NSLog(@"%@", writeError.description);
}

- (void) showAlertUpdateSucceeded {
    
    UIAlertView *alertSuccess = [[UIAlertView alloc] initWithTitle:@"Update Complete!" message:@"Firmware Update Succeeded!" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
    alertSuccess.tag = kAlertFirmwareUpdateResult;
    [alertSuccess show];
}

- (void) showAlertUpdateFailed {
    
    UIAlertView *alertFailure = [[UIAlertView alloc] initWithTitle:@"Update Failed!" message:@"Firmware Update Failed! Please try again." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
    alertFailure.tag = kAlertFactoryReset;
    [alertFailure show];
}

- (void) showAlertResetDevice {
    
    UIAlertView *alertReseDevice = [[UIAlertView alloc] initWithTitle:@"Reset Module!" message:@"Remote command mode not supported.  Please reset module before attempting to update firmware again." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
    [alertReseDevice show];
}

- (void) showAlertDisconnectedDevice {
    
    if ([[AppDelegate app].activePeripheral state] == CBPeripheralStateConnected) {
        
        UIAlertView *alertUpdateFailed = [[UIAlertView alloc] initWithTitle:@"Update Failed" message:@"Device connection lost. Device needs to be reconnected." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
        alertUpdateFailed.tag = kAlertViewDisconectedDevice;
        [alertUpdateFailed show];
    }
}

- (void) showAlertFirmwareNotFound {
    
    UIAlertView *alertFaileure = [[UIAlertView alloc] initWithTitle:@"Update Failed!" message:@"Couldn't find the requested firmware." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alertFaileure show];
}

- (void) showAlertFactoryReset {
    
    if ([[AppDelegate app].activePeripheral state] == CBPeripheralStateConnected) {
        
        UIAlertView *alertFactoryReset = [[UIAlertView alloc] initWithTitle:@"Factory Reset?" message:@"Factory reset the module after updating?" delegate:self cancelButtonTitle:nil otherButtonTitles:@"YES", @"NO", nil];
        alertFactoryReset.tag = kAlertFactoryReset;
        [alertFactoryReset show];
    
    }
}

- (void) showAlertHaltUpdate {
    
    if ([[AppDelegate app].activePeripheral state] == CBPeripheralStateConnected) {
        
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Cancel Update?" message:@"Are you sure? Leaving this view will cancel the update." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:@"Cancel", nil];
        alertView.tag = kAlertViewTagHaltUpdate;
        [alertView show];
    }
}

@end
