//
//  FirmwareUpdateViewController.h
//  sampleterm
//
//  Created by Neel Pansare on 5/20/14.
//
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "AppDelegate.h"
#import "Brsp.h"
#import "BrspManager.h"


typedef struct __attribute__((packed))
{
    UInt8 ledsEnabled;
    UInt8 messagesEnabled;
    UInt8 eraseLedRate;
    UInt8 writeLedRate;
    UInt8 verifyLedRate;
    UInt8 eraseStartPage;
    UInt8 eraseEndPage;
    
    UInt16 fwCrc;
    UInt32 fwAddr;
    UInt32 fwLen;
} brspUpdateHeader;


@interface FirmwareUpdateViewController : UIViewController <CBCentralManagerDelegate, BrspManagerDelegate>

@property (nonatomic, strong) NSString *firmwareUpdateFileName;
@property (nonatomic, strong) NSString *currentlyInstalledFirmware;
@property (nonatomic, strong) NSString *firmwarePath;
@property (nonatomic) BOOL shouldFactoryResetAfterUpdate;

@property (weak, nonatomic) IBOutlet UILabel *lblFirmwareUpdateFileName;
@property (weak, nonatomic) IBOutlet UIButton *btnUpdate;

@property (weak, nonatomic) IBOutlet UILabel *lblPercentage;

@property (strong, nonatomic) NSMutableArray *firmwareUpdateData;

- (void) setupViewController;

@end
