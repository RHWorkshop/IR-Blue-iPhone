
//  STConstants.h
//  sampleterm
//
//  Created by Neel Pansare on 5/23/14.
//  Copyright (c) 2013 BlueRadios. All rights reserved.
//

#define STCWhiteColor [UIColor colorWithRed:246.0/255.0 green:245.0/255.0 blue:241.0/255.0 alpha:1.0]
#define STCBlueColor [UIColor colorWithRed:19.0f/255.0f green:44.0f/255.0f blue:77.0f/255.0f alpha:1.0f]
#define STCCustomBlueColor [UIColor colorWithRed:43.48f/255.0f green:51.682f/255.0f blue:102.286f/255.0f alpha:1.0f]
#define STCFileTypeBru @".bru"
#define STCUpdateTYPE_S2 @"S2"
#define STCUpdateTYPE_S3 @"S3"
#define STCUpdateTYPE_PAN1720 @"PAN1720"
#define STCUpdateTYPE_PAN1721 @"PAN1721"
#define BrspManagerInstance [BrspManager sharedInstance]
#define sharedBrspObject [BrspManagerInstance getBrspObject]

typedef NS_ENUM(NSUInteger, STCUpdateType) {
    STCUpdateTypeS2 = 0,
    STCUpdateTypeS3 = 1,
    STCUpdateTypePAN1720 = 2,
    STCUpdateTypePAN1721 = 3,
    STCUpdateTypeUnknown = 100
};

typedef struct __attribute__((packed))  // header file definitions
{
    UInt16 cid;
    UInt16 pid;
    UInt16 mid;
    UInt16 fwCrc;
    UInt32 fwAddr;
    UInt32 fwLen;
    UInt16 hdrCrc;
} brzHdr_t;


#define kAlertFactoryReset 0
#define kAlertViewTagHaltUpdate 1
#define kAlertFirmwareUpdateResult 2
#define kAlertViewDisconectedDevice 3

#define kHelveticaNeueLightFontName @"HelveticaNeue-Light"
#define STCFirmwareVersionUnknown @"Unknown"

#define kATSCCPCommand @"ATSCCP,0,8,16,0,72"
#define kATVCommand @"ATV?"
#define kATRSTCommand @"ATRST"
#define STCErroneousFirmwareFileNames [NSArray arrayWithObjects:@"1.2.0.3.0.0", @"1.2.1.3.1.0", @"3.1.1.0", nil]

@interface STConstants : NSObject

+ (NSNumber *)roundFloatNearest2:(float)value;
+ (UIColor *)color:(UIColor *)color withAlpha:(float)alpha;

@end

static inline double radians (double degrees) { return degrees * M_PI/180; }
CGMutablePathRef createArcPathFromBottomOfRect(CGRect rect, CGFloat arcHeight);
