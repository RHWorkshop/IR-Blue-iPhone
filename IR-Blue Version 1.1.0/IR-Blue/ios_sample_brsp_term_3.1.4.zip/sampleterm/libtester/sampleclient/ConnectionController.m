//
//  ConnectionController.m
//  sampleterm
//
//  Created by Michael Testa on 11/1/12.
//  Copyright (c) Blueradios, Inc. All rights reserved.
//

#import "ConnectionController.h"
#import "FirmwareSelectionTableViewController.h"
#import "STConstants.h"
#import "UINavigationController+SafePushing.h"
#import "BrspManager.h"

//Make this number larger or smaller to see more or less output in the textview
#define MAX_TEXT_VIEW_CHARACTERS 1500
#define SAMPLE_APP_DEBUG_MODE 0  //Change to 1 to test bytes received with count and total time

@interface Brsp() {
    
}
//debug stuff
-(void)outputDebugTransferTime:(NSTimer *) theTimer;
-(void)startTimer;

@end

@implementation ConnectionController

@synthesize textView;
@synthesize inputText = _inputText;
@synthesize buttonChangeMode;
@synthesize buttonLeft;
@synthesize buttonClear;
@synthesize isFirmwareVersionInquiry;

#pragma mark - General Methods

- (void)viewDidLoad {
    [super viewDidLoad];
    [BrspManagerInstance resetBRSPObject];
    
    [_inputText setDelegate:self];
    _allCommands = [NSMutableArray new];
    [self loadCommandArray];
    _lastMode = BrspModeData; //Default brsp mode
    
    [self setEnabledUpdateFirmwareButton:NO];
}

-(void)loadCommandArray {
    _allCommands = [NSArray arrayWithObjects:
                    @"ATMT?",
                    @"ATV?",
                    @"ATA?",
                    @"ATSN?",
                    @"ATSZ?",
                    @"ATSFC?",
                    @"ATSCL?",
                    @"ATSRM?",
                    @"ATSDIF?",
                    @"ATSPL?",
                    @"ATSUART?",
                    @"ATSPIO?,0",
                    @"ATSPIO?,1",
                    @"ATSPIO?,2",
                    @"ATSPIO?,3",
                    @"ATSPIO?,4",
                    @"ATSPIO?,5",
                    @"ATSPIO?,6",
                    @"ATSPIO?,7",
                    @"ATSPIO?,8",
                    @"ATSPIO?,9",
                    @"ATSPIO?,10",
                    @"ATSPIO?,11",
                    @"ATSPIO?,12",
                    @"ATSPIO?,13",
                    @"ATSPIO?,14",
                    @"ATSLED?,0",
                    @"ATSLED?,1",
                    @"ATSSP?",
                    @"ATSPK?",
                    @"ATSDBLE?",
                    @"ATSBRSP?",
                    @"ATSDSLE?",
                    @"ATSDSTLE?",
                    @"ATSDILE?",
                    @"ATSDITLE?",
                    @"ATSDMTLE?",
                    @"ATSDCP?",
                    @"ATSPLE?",
                    //D2 Modules only
                    //                    @"ATS?",
                    //                    @"ATLCA?",
                    //                    @"ATSP?",
                    //                    @"ATSCOD?",
                    nil];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    [self disableButtons];
    [AppDelegate app].cbCentral.delegate = self;
    
    [BrspManager sharedInstance].delegate = self;
    
    _outputText = [NSMutableString stringWithCapacity:MAX_TEXT_VIEW_CHARACTERS];
    
    self.navigationItem.title = [AppDelegate app].activePeripheral.name;
    
    UIBarButtonItem *btnUpdateFirmware         = [[UIBarButtonItem alloc]
                                                  initWithBarButtonSystemItem:UIBarButtonSystemItemAction
                                                  target:self
                                                  action:@selector(updateFirmwareTapped:)];
    
    self.navigationItem.rightBarButtonItems = [NSArray arrayWithObjects: btnUpdateFirmware, nil];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@" Back" style:UIBarButtonItemStyleBordered target:self action:@selector(goBack:)];
    
    if ([[UIDevice currentDevice].systemVersion floatValue] == 7.0) {
        //Manualy create a textView manually as a workaround to the iOS 7 scroll bug
        //See http://stackoverflow.com/a/19339716/672113
        NSTextStorage* textStorage = [[NSTextStorage alloc] init];
        NSLayoutManager* layoutManager = [NSLayoutManager new];
        [textStorage addLayoutManager:layoutManager];
        NSTextContainer *textContainer = [[NSTextContainer alloc] initWithSize:self.view.bounds.size];
        [layoutManager addTextContainer:textContainer];
        UIFont *font = textView.font;
        textView = [[UITextView alloc] initWithFrame:textView.bounds textContainer:textContainer];
        textView.font = font;
        [self.view addSubview:textView];
    }
    
    [self enableButtons];
    [self clearOutputTapped:nil];
}

-(void)viewDidAppear:(BOOL)animated {
    
    //Use CBCentral Manager to connect this peripheral
    _hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    _hud.labelText = @"Connecting";
    
    [self connectPeripheral];
    
    _isIntentionalDisconnect = NO;
    isFirmwareVersionInquiry = NO;
}

- (void)viewDidUnload {
    [super viewDidUnload];
}

- (void)viewWillDisappear:(BOOL)animated {
    [_connectionTimer invalidate];
    [MBProgressHUD hideHUDForView:self.view animated:YES];
}

-(void)viewDidDisappear:(BOOL)animated {

	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    switch(interfaceOrientation)
    {
        case UIInterfaceOrientationLandscapeLeft:
            return NO;
        case UIInterfaceOrientationLandscapeRight:
            return NO;
        default:
            return YES;
    }
}


#pragma mark BrspManagerDelegate

- (void) brsp:(Brsp*)brsp openStatusChanged:(BOOL)isOpen {
    
    [MBProgressHUD hideHUDForView:self.view animated:YES];
    if (isOpen) {
        //The BRSP object is ready to be used
        [self enableButtons];
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        //Print the security level of the brsp service to console
        NSLog(@"BRSP Security Level is %lu", (unsigned long)[BrspManager sharedInstance].brspObject.securityLevel);
    } else {
        
        if ([[AppDelegate app].activePeripheral state] == CBPeripheralStateConnected) {
            
            [self disconnectPeripheral];
        }
    }
}

- (void) brsp:(Brsp*)brsp sendingStatusChanged:(BOOL)isSending {
    //This is a good place to change BRSP mode
    //If we are on the last command in the queue and we are no longer sending, change the mode back to previous value
    
    if (_commandQueue == nil) {
        
        return;
    }
    
    if (isSending == NO && _commandQueue.count < 2)
    {
        if (_lastMode == [BrspManager sharedInstance].brspObject.brspMode)
            return;  //Nothing to do here
        // Change mode back to previous setting
        NSError *error = [[BrspManager sharedInstance].brspObject changeBrspMode:_lastMode];
        if (error)
            NSLog(@"%@", error);
    }
}
- (void) brspDataReceived:(Brsp*)brsp {
    NSLog(@"Data recieved");

    // Firmware Version Inquiry response
    if(isFirmwareVersionInquiry) {
        
        //The data incomming is in response to a sent command.
        NSString *response = [self parseFullCommandResponse];
        if (!response)
            return; //Buffer doesn't contain a full command reponse yet;
        
        NSString *responseData = [self parseCommandData:response];
        if (responseData != nil) {
            
            _firmwareVersionOutput = responseData;
        }
        
        [self DoneGettingFirmwareVersion];
        
        return;
    }
    
    //If there are items in the _commandQueue array, assume this data is part of a command response
    if (_commandQueue.count > 0)
    {
        //The data incomming is in response to a sent command.
        NSString *response = [self parseFullCommandResponse];
        if (!response)
            return; //Buffer doesn't contain a full command reponse yet;
        
        NSString *responseData = [self parseCommandData:response];
        [self outputCommandWithResponse:responseData];
        
        [_commandQueue removeObjectAtIndex:0]; //Remove last sent command from our queue array
        //Remove the full response from the brsp input buffer
        [[BrspManager sharedInstance].brspObject flushInputBuffer:response.length];
        
        if (_commandQueue.count > 0)
            //Send the next command
            [self sendCommand:[_commandQueue objectAtIndex:0]];
        else
        {
            //Done sending commands...
            [self enableButtons];
            //Print a footer
            [self outputToScreen:@"  ________________________________\r"];
        }
        
    }
    else
    {
        //The data comming in is not from a sent command
        //Just output the response to screen and remove from the input buffer using a readString
        NSString *outputString = [[BrspManager sharedInstance].brspObject readString];
        //Set SAMPLE_APP_DEBUG_MODE to 1 if you want to time incoming bytes coming in (Good for testing if all bytes have been recieved from a remote device)
        if (SAMPLE_APP_DEBUG_MODE) {
            _byteCount += outputString.length;
            self.labelByteCount.text = [NSString stringWithFormat:@"%d bytes", _byteCount];
            [self startTimer];
        } else {
            self.labelByteCount.text = @"";
            self.labelTimeTaken.text = @"";
            NSLog(@"Outputting: %@", outputString);
            [self outputToScreen:outputString];
        }
    }
}

- (void) brsp:(Brsp*)brsp errorReceived:(NSError*)error {
    NSLog(@"%@", error.description);
    [self disconnectPeripheral];
}

- (void) brspModeChanged:(Brsp*)brsp BRSPMode:(BrspMode)mode {
    switch (mode) {
        case BrspModeData:
            
            [self.buttonChangeMode setTitle:[NSString stringWithFormat:@"Data"] forState:UIControlStateNormal];
            [self.buttonLeft setTitle:@"Send10" forState:UIControlStateNormal];
            [self enableButton:self.buttonLeft];
            [self.buttonLeft removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
            [self.buttonLeft addTarget:self action:@selector(send10:) forControlEvents:UIControlEventTouchUpInside];
            [self enableButton:self.buttonClear];
            break;
        case BrspModeRemoteCommand:
            
            // Inquire the current firmware version
            if (isFirmwareVersionInquiry) {
                
                [self sendCommand:kATVCommand];
                return;
            }
            
            [self.buttonChangeMode setTitle:[NSString stringWithFormat:@"Command"] forState:UIControlStateNormal];
            [self.buttonLeft setTitle:@"Settings" forState:UIControlStateNormal];
            [self enableButton:self.buttonLeft];
            [self.buttonLeft removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
            [self.buttonLeft addTarget:self action:@selector(getSettings:) forControlEvents:UIControlEventTouchUpInside];
            [self enableButton:self.buttonClear];
            break;
            
        case BrspModeFirmwareUpdate:
            
            break;
        default:
            [self disableButton:self.buttonLeft];
            break;
    }
}

//Calculates time taken and outputs it to the screen when SAMPLE_APP_DEBUG_MODE set to 1
-(void)outputDebugTransferTime:(NSTimer *) theTimer {
    _debugTimer = nil;
    _byteCount = 0;
    NSTimeInterval debugEndTime = [[NSDate date] timeIntervalSince1970];
    self.labelTimeTaken.text = [NSString stringWithFormat:@"%.02f seconds", (debugEndTime - _debugStartTime) - 1];
}
-(void)startTimer {
    if (!_debugTimer) {
        _debugStartTime = [[NSDate date] timeIntervalSince1970];
    } else {
        [_debugTimer invalidate];
    }
    self.labelTimeTaken.text = @"";
    _debugTimer =  [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(outputDebugTransferTime:) userInfo:nil repeats:NO];
}

//Calculates time taken and outputs it to the screen when SAMPLE_APP_DEBUG_MODE set to 1
- (void) DoneGettingFirmwareVersion {
    
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    
    isFirmwareVersionInquiry = NO;
    
    // Launch Firmware Selection Screen
    if(_firmwareVersionOutput != nil)
        
        [self launchFirmwareSelectionScreen:_firmwareVersionOutput];
    else
        
        [self launchFirmwareSelectionScreen:STCFirmwareVersionUnknown];
}

#pragma mark CBCentralManagerDelegate
- (void)centralManagerDidUpdateState:(CBCentralManager *)central {
    
}

- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral {
    
    [_connectionTimer invalidate];
    _hud.labelText = @"Discovering characteristics";
    [[BrspManager sharedInstance].brspObject open];
    
    [self setEnabledUpdateFirmwareButton:[[BrspManager sharedInstance].brspObject isFirmwareUpdateModeSupported]];
}

- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    
    // put back the brsp mode to default idle mode
    //[BrspManagerInstance.brspObject changeBrspMode:BrspModeIdle];
    
    if (_isIntentionalDisconnect == NO) {
        
        [self connectPeripheral];
    }
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void) connectPeripheral {
    
    _connectionTimer = [NSTimer scheduledTimerWithTimeInterval:(float)8.0 target:self selector:@selector(cancelConnectionTimout) userInfo:nil repeats:NO];
    [[AppDelegate app].cbCentral connectPeripheral:[AppDelegate app].activePeripheral options:nil];
}

- (void)cancelConnectionTimout {
    NSLog(@"connectionTimeout reached.");
    [NSTimer scheduledTimerWithTimeInterval:(float)2.0 target:self selector:@selector(disconnectTimer) userInfo:nil repeats:NO];
}

- (void)disconnectTimer {
    
    [_hud hide:YES];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"An error occurred while interacting with the module. Please try again." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
    
    if([AppDelegate app].activePeripheral.state == CBPeripheralStateConnected)
        [self disconnectPeripheral];
    else
        [self.navigationController popToRootViewControllerAnimated:YES];
}

- (IBAction) goBack: (id) sender {
    
    _isIntentionalDisconnect = YES;
    [[BrspManager sharedInstance].brspObject close];
    [self.navigationController popToRootViewControllerAnimated:YES];
}


- (void) disconnectPeripheral {
    
    [[AppDelegate app].cbCentral cancelPeripheralConnection:[AppDelegate app].activePeripheral];
}


#pragma mark - UITextFieldDelegate methods

-(BOOL) textFieldShouldReturn:(UITextField *)textField {
    _lastMode = [BrspManager sharedInstance].brspObject.brspMode;
    
    if ([[AppDelegate app].activePeripheral state] == CBPeripheralStateDisconnected) {
        _isIntentionalDisconnect = NO;
        return YES;
    }
    
    if (_lastMode == BrspModeData && ![BrspManager sharedInstance].brspObject.isDataModeSupported) {
        
        [self showAlertDataModeNotSupported];
        textField.text = @"";
        [textField resignFirstResponder];
        return YES;
    }
    
    if (_lastMode == BrspModeRemoteCommand && ![BrspManager sharedInstance].brspObject.isRemoteCommandModeSupported) {
        
        [self showAlertCommandModeNotSupported];
        textField.text = @"";
        [textField resignFirstResponder];
        return YES;
    }
    
    //Write whatever user typed in textfield to brsp peripheral
    NSError *error = [[BrspManager sharedInstance].brspObject writeString:[NSString stringWithFormat:@"%@\r", textField.text]];
    if (error)
        NSLog(@"%@", error.description);
    textField.text = @"";
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    [self animateTextField:textField up: YES];
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    [self animateTextField:textField up: NO];
}

- (void) animateTextField:(UITextField*)textField up:(BOOL)up {
    int movementDistance = 172; //will only work on iPhones (iPhone 4)
    if (textView.bounds.size.height > 331.0)
        movementDistance = 184; //iPhone 5 assumed
    const float movementDuration = 0.3f;
    
    int movement = (up ? -movementDistance : movementDistance);
    
    [UIView beginAnimations: @"anim" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}

#pragma mark - UI

- (void) setEnabledUpdateFirmwareButton : (BOOL) enabled {
    
    [[self.navigationItem.rightBarButtonItems objectAtIndex:0] setEnabled:enabled];
}

- (IBAction)updateFirmwareTapped:(id)sender {
    
    _hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    _hud.labelText = @"Getting Firmware Info...";
    
    // Clear communication buffers
    [[BrspManager sharedInstance].brspObject flushOutputBuffer];
    [[BrspManager sharedInstance].brspObject flushInputBuffer];
    
    [self setEnabledUpdateFirmwareButton:NO];
    
    isFirmwareVersionInquiry = YES;

    // empty command queue
    [_commandQueue removeAllObjects];
    
    // If connection not open - open connection otherwise get firmware info
    if ([[BrspManager sharedInstance].brspObject isOpen] != YES) {
        [[BrspManager sharedInstance].brspObject open];
    } else {
        
        // If remote command mode supported get the current firmware version
        if ([BrspManager sharedInstance].brspObject.isRemoteCommandModeSupported && [BrspManager sharedInstance].brspObject.isFirmwareUpdateModeSupported) {
            
            if ([BrspManager sharedInstance].brspObject.brspMode != BrspModeRemoteCommand) {
                
                [[BrspManager sharedInstance].brspObject changeBrspMode:BrspModeRemoteCommand];
            } else {
                
                // Inquire the current firmware version
                [self sendCommand:kATVCommand];
            }
        } else if([BrspManager sharedInstance].brspObject.isFirmwareUpdateModeSupported) {
            
            // If remote command mode is not supported then proceed to next screen without the firmware version info.
            [[BrspManager sharedInstance].brspObject close];
        }
    }
}

- (IBAction)clearOutputTapped:(id)sender {
    [textView setText:@""];
    [_outputText setString:@""];
}

- (IBAction)send10:(id)sender {
    
    if ([[AppDelegate app].activePeripheral state] == CBPeripheralStateDisconnected) {
        _isIntentionalDisconnect = NO;
        return;
    }
    
    if (![BrspManager sharedInstance].brspObject.isDataModeSupported) {
        
        [self showAlertDataModeNotSupported];
        return;
    }
    
    //Save the brsp mode so it can be switched back when this process is complete
    _lastMode = [BrspManager sharedInstance].brspObject.brspMode;
    if ([BrspManager sharedInstance].brspObject.brspMode != BrspModeData)
        [[BrspManager sharedInstance].brspObject changeBrspMode:BrspModeData]; //change brsp mode to data
    for (int i=1; i <= 10; i++) {
        //Write numbers 1-10 to the device
        NSError *error = [[BrspManager sharedInstance].brspObject writeString:[NSString stringWithFormat:@"%i\r\n", i%10]];
        if (error)
            NSLog(@"%@", error.description);
    }
}

//Runs all commands in the _allCommands array
- (IBAction)getSettings:(id)sender {
    
    if ([[AppDelegate app].activePeripheral state] == CBPeripheralStateDisconnected) {
        _isIntentionalDisconnect = NO;
        return;
    }
    
    if ([BrspManager sharedInstance].brspObject.isRemoteCommandModeSupported) {
        //Save the brsp mode so it can be switched back when this process is complete
        _lastMode = [BrspManager sharedInstance].brspObject.brspMode;
        if ([BrspManager sharedInstance].brspObject.brspMode != BrspModeRemoteCommand) {
            //Switch to remote command mode
            NSError *modeChangeError = [[BrspManager sharedInstance].brspObject changeBrspMode:BrspModeRemoteCommand];
            if (modeChangeError)
                NSLog(@"%@", modeChangeError);
        }
        //Disable buttons
        [self disableButtons];
        //load a command queue
        _commandQueue = [NSMutableArray arrayWithArray:_allCommands];
        //send first command
        [self sendCommand:[_commandQueue objectAtIndex:0]];
    } else {
        
        [self showAlertCommandModeNotSupported];
    }
}

//Flips the brsp mode between data and remote command
- (IBAction)changeMode:(id)sender {
    BrspMode newMode = ([BrspManager sharedInstance].brspObject.brspMode==BrspModeData) ? BrspModeRemoteCommand : BrspModeData;
    
    if (newMode == BrspModeRemoteCommand && ![BrspManager sharedInstance].brspObject.isRemoteCommandModeSupported) {
        
        [self showAlertCommandModeNotSupported];
        return;
    }
    
    if (newMode == BrspModeData && ![BrspManager sharedInstance].brspObject.isDataModeSupported) {
        
        [self showAlertDataModeNotSupported];
        return;
    }
    
    NSError *error = [[BrspManager sharedInstance].brspObject changeBrspMode:newMode];
    if (error)
        NSLog(@"%@", error);
}

- (void)enableButtons {
    [self enableButton:self.buttonChangeMode];
    
    if ([BrspManager sharedInstance].brspObject.isFirmwareUpdateModeSupported) {
        
        [self setEnabledUpdateFirmwareButton:YES];
    }
    
    if ([BrspManager sharedInstance].brspObject.brspMode == BrspModeRemoteCommand) {
        
        [self enableButton:self.buttonClear];
        [self enableButton:self.buttonLeft];
    }
    
    if ([BrspManager sharedInstance].brspObject.brspMode == BrspModeData)
        [self enableButton:self.buttonLeft];
    
    [self.inputText setEnabled:YES];
}

- (void)disableButtons {
    [self disableButton:self.buttonChangeMode];
    [self disableButton:self.buttonClear];
    [self disableButton:self.buttonLeft];
    [self setEnabledUpdateFirmwareButton:NO];
    [self.inputText setEnabled:NO];
}

- (void)enableButton:(UIButton*)butt {
    butt.enabled = YES;
    butt.alpha = 1.0;
}

- (void)disableButton:(UIButton*)butt {
    butt.enabled = NO;
    butt.alpha = 0.5;   
}

//Returns the full command string or nil.  (Up to and including the 4th "\r\n")
-(NSString*)parseFullCommandResponse {
    //Peek at the entire brsp input buffer and see if it contains a full AT command response
    NSString *tmp = [[BrspManager sharedInstance].brspObject peekString];
    NSUInteger crlfcount = 0, length = [tmp length];
    NSRange range = NSMakeRange(0, length);

    while(range.location != NSNotFound && crlfcount != 4) {
        range = [tmp rangeOfString: @"\r\n" options:0 range:range];
        if(range.location != NSNotFound) {
            range = NSMakeRange(range.location + range.length, length - (range.location + range.length));
            crlfcount++;
        }
    }
    
    if (crlfcount==4)
        return [tmp substringWithRange:NSMakeRange(0, range.location)];
    else
        return nil;
}

//Returns the data portion from a command response string.  (String between the 3rd and 4th "\r\n"
-(NSString*)parseCommandData:(NSString*)fullCommandResponse {
    NSArray *array = [fullCommandResponse componentsSeparatedByString:@"\r\n"];
    if (array && array.count > 3)
        return [array objectAtIndex:3];
    else
        return @"";
}

//Outputs the next command in the _sentCommands array with the response to the screen and removes it from the array
-(void)outputCommandWithResponse:(NSString*)response {
    NSString *commandName = (NSString *)[_commandQueue objectAtIndex:0];
    [self outputToScreen:[NSString stringWithFormat:@"%@=%@\r", commandName, response]];
}

-(void)sendCommand:(NSString *)str {
    if (![[str substringFromIndex:str.length-1] isEqualToString:@"\r"])
        str = [NSString stringWithFormat:@"%@\r", str];  //Append a carriage return
    //Write as string 
    NSError *writeError = [[BrspManager sharedInstance].brspObject writeString:str];
    if (writeError)
        NSLog(@"%@", writeError.description);
}

-(void)outputToScreen:(NSString *)str {
    if (!str || !str.length) return;  //Nothing to output
    
    [_outputText appendString:str];
//    [_outputText insertString:str atIndex:0];  //Use this line if you want to reverse

    //Autoscroll will not work on iOS 7.  See comments on the following function
    [self scrollOutputToBottom];
}

//Part of the iOS 7 scroll hack above
-(void)scrollToBottom:(NSTimer *) theTimer {
    [_scrollTimer invalidate];
    _scrollTimer = nil;
    [self scrollOutputToBottom];
}

//In iOS 7 scrolling seems choppy and does not work well no matter what I tried.  The following code
//will not scroll on iOS 7 devices, so autoscroll will effectively be disabled until this possible bug in
//UITextView is fixed.  If you know a way to make auto scrolling work smoothly on all iOS versions, please let us know! :-)
//Here is a related post http://stackoverflow.com/questions/19124037/scroll-to-bottom-of-uitextview-erratic-in-ios-7-with-many-updates
-(void)scrollOutputToBottom {
    //truncate the UITextView text if larger than MAX_TEXT_VIEW_CHARACTERS
    NSInteger outputTextSize = _outputText.length;
    if (outputTextSize > MAX_TEXT_VIEW_CHARACTERS)
        [_outputText deleteCharactersInRange:NSMakeRange(0, outputTextSize - MAX_TEXT_VIEW_CHARACTERS)];
    //The following commented line would remove characters from the text in reverse
    //        [_outputText deleteCharactersInRange:NSMakeRange(MAX_TEXT_VIEW_CHARACTERS, outputTextSize - MAX_TEXT_VIEW_CHARACTERS)];
    [textView setText:_outputText];

    //Scroll to bottom of textView
    
    CGPoint offset = CGPointMake(0, textView.contentSize.height - textView.frame.size.height);
    [self.textView setContentOffset:offset animated:NO];
//    CGRect caretRect = [textView caretRectForPosition:textView.endOfDocument];
//    [textView scrollRectToVisible:caretRect animated:NO];
    
//    [self.textView scrollRangeToVisible:NSMakeRange(textView.text.length, 0)];
}


- (void) launchFirmwareSelectionScreen: (NSString *) currentFirmwareName {
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"MainStoryboard" bundle:nil];
    FirmwareSelectionTableViewController *firmwareSelectionViewController = (FirmwareSelectionTableViewController *)[storyboard instantiateViewControllerWithIdentifier:@"FirmwareSelectionTableViewController"];
    firmwareSelectionViewController.currentFirmware = currentFirmwareName;
    
    // Safe pushing
    id lock = self.navigationController.navigationLock;
    
    // if already pushed do not push again.
    if ([[self.navigationController.viewControllers lastObject] isKindOfClass:FirmwareSelectionTableViewController.class]) {
        return;
    }
    
    [self.navigationController pushViewController:firmwareSelectionViewController animated:YES navigationLock:lock];
}

#pragma mark - UIAlertView Delegate Methods

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    
    switch (alertView.tag) {
            
        default:
            break;
    }
}

- (void) showAlertDataModeNotSupported {
    
    UIAlertView *alertDataModeNotSupported = [[UIAlertView alloc] initWithTitle:@"Warning!"
                                                                          message:@"Data mode is not supported. Please enable Data Mode"
                                                                         delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alertDataModeNotSupported show];
}

- (void) showAlertDisconnectedDevice {
    
    UIAlertView *alertUpdateFailed = [[UIAlertView alloc] initWithTitle:@"Connection Lost!" message:@"Device connection lost. Device needs to be reconnected." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
    [alertUpdateFailed show];
}

- (void) showAlertCommandModeNotSupported {
    
    UIAlertView *alertCommandModeUnsupported = [[UIAlertView alloc] initWithTitle:@"Warning!"
                                                                          message:@"Remote command mode is not supported."
                                                                         delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alertCommandModeUnsupported show];
}

- (void) showAlertUnableToProceedToFirmwareUpdate {
    
    UIAlertView *alertUnableToProceedToFirmwareUpdate = [[UIAlertView alloc] initWithTitle:@"Warning!"
                                                                          message:@"Unable to proceed to Firmware Update. Please try again."
                                                                         delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alertUnableToProceedToFirmwareUpdate show];
}

@end
