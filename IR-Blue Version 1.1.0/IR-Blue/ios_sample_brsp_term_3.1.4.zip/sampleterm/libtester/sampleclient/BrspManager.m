//
//  BrspManager.m
//  sampleterm
//
//  Created by Neel Pansare on 6/24/14.
//
//

#import "BrspManager.h"
#import "AppDelegate.h"

@implementation BrspManager


- (id)init {
    
    _brspObject = [[Brsp alloc] initWithPeripheral:[AppDelegate app].activePeripheral InputBufferSize:512 OutputBufferSize:512];
    _brspObject.delegate = self;
    return self;
}

- (void) dealloc {
    
}

- (void) resetBRSPObject {
    
    _brspObject = nil;
    _brspObject = [[Brsp alloc] initWithPeripheral:[AppDelegate app].activePeripheral InputBufferSize:512 OutputBufferSize:512];
    _brspObject.delegate = self;
}

+ (BrspManager *) sharedInstance {
    static dispatch_once_t once;
    static BrspManager * sharedInstance; dispatch_once(&once, ^{
        sharedInstance = [[self alloc] init]; });
    return sharedInstance;
}

#pragma mark BRSP Delegate Methods

- (void)brsp:(Brsp*)brsp OpenStatusChanged:(BOOL)isOpen {
    
    // callback to make necessary changes to the delegate
    if(_delegate && [_delegate respondsToSelector:@selector(brsp:openStatusChanged:)]) {
        [_delegate brsp:_brspObject openStatusChanged:isOpen];
    }
}

- (void)brspModeChanged:(Brsp*)brsp BRSPMode:(BrspMode)mode {
    
    // callback to make necessary changes to the delegate
    if(_delegate && [_delegate respondsToSelector:@selector(brspModeChanged:BRSPMode:)]) {
        [_delegate brspModeChanged:_brspObject BRSPMode:mode];
    }
}

// Data Received Call Back function gets called after writeBytes is executed successfully
- (void)brspDataReceived:(Brsp*)brsp {
    
    // callback to make necessary changes to the delegate
    if(_delegate && [_delegate respondsToSelector:@selector(brspDataReceived:)]) {
        [_delegate brspDataReceived:_brspObject];
    }
}

- (void)brsp:(Brsp*)brsp SendingStatusChanged:(BOOL)isSending {
    
    // callback to make necessary changes to the delegate
    if(_delegate && [_delegate respondsToSelector:@selector(brsp:sendingStatusChanged:)]) {
        [_delegate brsp:_brspObject sendingStatusChanged:isSending];
    }
}

- (void)brsp:(Brsp*)brsp ErrorReceived:(NSError*)error {
    
    // callback to make necessary changes to the delegate
    if(_delegate && [_delegate respondsToSelector:@selector(brsp:errorReceived:)]) {
        [_delegate brsp:_brspObject errorReceived:error];
    }
}

@end
