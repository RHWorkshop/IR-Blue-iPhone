//
//  AppDelegate.h
//  sampleterm
//
//  Created by Michael Testa on 11/1/12.
//  Copyright (c) Blueradios, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) CBCentralManager *cbCentral;
@property (strong, nonatomic) CBPeripheral *activePeripheral;

//Returns a pointer to the shared AppDelegate
+(AppDelegate*)app;

@end
