//
//  BrspManager.h
//  sampleterm
//
//  Created by Neel Pansare on 6/24/14.
//
//

#import <Foundation/Foundation.h>
#import "Brsp.h"

// BRSP Callbacks
@protocol BrspManagerDelegate <NSObject>

@required

- (void) brsp:(Brsp*)brsp openStatusChanged:(BOOL)isOpen;
- (void) brspModeChanged:(Brsp*)brsp BRSPMode:(BrspMode)mode;
- (void) brspDataReceived:(Brsp*)brsp;

@optional

- (void) brsp:(Brsp*)brsp sendingStatusChanged:(BOOL)isSending;
- (void)brsp:(Brsp*)brsp errorReceived:(NSError*)error;

@end

@interface BrspManager : NSObject <BrspDelegate>

+ (BrspManager *)sharedInstance;
- (void) resetBRSPObject;

@property (nonatomic, weak) id <BrspManagerDelegate> delegate;
@property (strong, nonatomic) Brsp *brspObject;

@end
