//
//  BKConstants.m
//  sampleterm
//
//  Created by Neel Pansare on 5/23/14.
//  Copyright (c) 2013 BlueRadios. All rights reserved.
//

#import "STConstants.h"

@implementation STConstants : NSObject

+ (NSNumber *)roundFloatNearest2:(float)value{
    float nearest = floorf(value * 100.0f + 0.5f) / 100.0f;
    return [NSNumber numberWithFloat:nearest];
}

+ (UIColor *)color:(UIColor *)color withAlpha:(float)alpha{
    CGFloat red = 0.0, green = 0.0, blue = 0.0, oldAlpha = 0.0;
    [color getRed:&red green:&green blue:&blue alpha:&oldAlpha];
    
    return [UIColor colorWithRed:red green:green blue:blue alpha:alpha];
}

+ (void)colorizeView:(UIView *)view
{
    static CGFloat alpha = 0.1f;
    
    view.backgroundColor = [[UIColor blueColor] colorWithAlphaComponent:alpha];
    alpha += 0.1f;
    
    for (UIView *subview in view.subviews) {
        [self colorizeView:subview];
    }
    
    alpha -= 0.1f;
}

@end

