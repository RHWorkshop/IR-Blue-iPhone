//
//  AlertviewManager.h
//  sampleterm
//
//  Created by Neel Pansare on 6/17/14.
//
//

#import <Foundation/Foundation.h>

#define kAlertFactoryReset 0
#define kAlertFirmwareUpdateResult 1
#define kAlertViewTagHaltUpdate 2
#define kAlertViewDisconectedDevice 3


@interface AlertviewManager : NSObject <UIAlertViewDelegate>

+ (AlertviewManager *)sharedInstance;


- (void) showAlertUpdateSucceeded;
- (void) showAlertUpdateFailed;
- (void) showAlertDisconnectedDevice;
- (void) showAlertFirmwareNotFound;

@end
