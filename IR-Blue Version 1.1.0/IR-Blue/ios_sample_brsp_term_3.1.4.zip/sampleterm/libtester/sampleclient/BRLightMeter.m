//
//  BRLightMeter.m
//  BlueSense
//
//  Created by Phil Beadle on 5/20/13.
//  Copyright (c) 2013 BlueRadios. All rights reserved.
//

#import "BRLightMeter.h"
#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>
#import "STConstants.h"

@interface BRLightMeter()

@property (nonatomic, strong) UIImageView *sensorImageView;
@property (nonatomic, strong) UIImageView *raysImageView;
@property (nonatomic, strong) NSDate *lastUpdated;
@property (nonatomic, strong) NSNumber *lastProgressValue;
@property (nonatomic, strong) NSNumber *lastSecondaryProgressLowValue;
@property (nonatomic, strong) NSNumber *lastSecondaryProgressHighValue;
@property (nonatomic, strong) CAShapeLayer *backgroundSecondaryShapeLayer;
@property (nonatomic, strong) CAShapeLayer *shapeLayer;
@property (nonatomic, strong) CAShapeLayer *secondaryShapeLayer;
@property (nonatomic, strong) NSString *productId;

@end

@implementation BRLightMeter

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setBackgroundColor:[UIColor clearColor]];
        _sensorImageView = [[UIImageView alloc] initWithFrame:CGRectMake((frame.size.width-58)/2, frame.size.height - 68, 58, 58)];
        [_sensorImageView setContentMode:UIViewContentModeCenter];
        [_sensorImageView setImage:[UIImage imageNamed:@"light_white.png"]];
        [self addSubview:_sensorImageView];
        
        self.lastSecondaryProgressLowValue = @0.0f;
        self.lastSecondaryProgressHighValue = @1.0f;
        
        [self setupProgressLayer];
        
        _lastUpdated = [NSDate date];
        
    }
    return self;
}

- (CGRect)ovalRect {
    return CGRectMake((self.frame.size.width-120)/2, self.frame.size.height-105, 120, 120);
}

- (void)setupProgressLayer {
    CGRect ovalRect = [self ovalRect];
    
    UIBezierPath *ovalPath = [UIBezierPath bezierPath];
   
    [ovalPath addArcWithCenter:CGPointMake(CGRectGetMidX(ovalRect), CGRectGetMidY(ovalRect)) radius:CGRectGetWidth(ovalRect) / 2 startAngle:radians(135) endAngle:radians(45) clockwise:YES];
    ovalPath.lineWidth = 12.0f;

    CAShapeLayer *backgroundShapeLayer = [CAShapeLayer layer];
    backgroundShapeLayer.path = [ovalPath CGPath];
    backgroundShapeLayer.strokeColor = [UIColor colorWithWhite:1.0 alpha:0.2].CGColor;
    backgroundShapeLayer.fillColor = nil;
    backgroundShapeLayer.lineWidth = 12.0f;
    backgroundShapeLayer.lineJoin = kCALineJoinMiter;
    [self.layer addSublayer:backgroundShapeLayer];
    
    _shapeLayer = [CAShapeLayer layer];
    _shapeLayer.path = [ovalPath CGPath];
    _shapeLayer.strokeColor = [[UIColor whiteColor] CGColor];
    _shapeLayer.fillColor = nil;
    _shapeLayer.lineWidth = 9.5f;
    _shapeLayer.lineJoin = kCALineJoinMiter;
    [self.layer addSublayer:_shapeLayer];
}


- (void)setupSecondaryProgressLayer{
    
    CGRect ovalRect = [self ovalRect];
    
    UIBezierPath *secondaryOvalPath = [UIBezierPath bezierPath];
    
    [secondaryOvalPath addArcWithCenter:CGPointMake(CGRectGetMidX(ovalRect), CGRectGetMidY(ovalRect)) radius:[self secondaryProgressViewRadius] startAngle:radians(135) endAngle:radians(45) clockwise:YES];
    
    secondaryOvalPath.lineWidth = 2.0f;
    
    if (self.backgroundSecondaryShapeLayer){
        [self.backgroundSecondaryShapeLayer removeFromSuperlayer];
        self.backgroundSecondaryShapeLayer = nil;
    }
    
    if (self.secondaryShapeLayer) {
        [self.secondaryShapeLayer removeFromSuperlayer];
        self.secondaryShapeLayer = nil;
    }
    
    _backgroundSecondaryShapeLayer = [CAShapeLayer layer];
    self.backgroundSecondaryShapeLayer.path = secondaryOvalPath.CGPath;
    self.backgroundSecondaryShapeLayer.strokeColor = [STConstants color:[UIColor redColor] withAlpha:0.9f].CGColor;
    self.backgroundSecondaryShapeLayer.fillColor = nil;
    self.backgroundSecondaryShapeLayer.lineWidth = 4.0f;
    self.backgroundSecondaryShapeLayer.lineJoin = kCALineJoinMiter;
    [self.layer addSublayer:self.backgroundSecondaryShapeLayer];
    
    _secondaryShapeLayer = [CAShapeLayer layer];
    self.secondaryShapeLayer.path = [secondaryOvalPath CGPath];
    self.secondaryShapeLayer.strokeColor = [STConstants color:STCBlueColor withAlpha:1.0f].CGColor;
    self.secondaryShapeLayer.fillColor = nil;
    self.secondaryShapeLayer.lineWidth = 5.0f;
    self.secondaryShapeLayer.lineJoin = kCALineJoinMiter;
    [self.layer addSublayer:self.secondaryShapeLayer];
    
    if (self.secondaryProgressLowLabel) {
        [self.secondaryProgressLowLabel removeFromSuperview];
        self.secondaryProgressLowLabel = nil;
    }
    
    if (self.secondaryProgressHighLabel) {
        [self.secondaryProgressHighLabel removeFromSuperview];
        self.secondaryProgressHighLabel = nil;
    }
    
    self.secondaryProgressLowLabel = [self newSecondaryProgressLabel];
    CGPoint lowLabelCenterPoint = CGPointMake(0, CGRectGetMaxY([self ovalRect]));
    self.secondaryProgressLowLabel.center = lowLabelCenterPoint;
    self.secondaryProgressLowLabel.text = [self.lastSecondaryProgressLowValue stringValue];
    [self addSubview:self.secondaryProgressLowLabel];
    
    self.secondaryProgressHighLabel = [self newSecondaryProgressLabel];
    CGPoint highLabelCenterPoint = CGPointMake(CGRectGetWidth(self.bounds) - 4.0f, CGRectGetMaxY([self ovalRect]));
    self.secondaryProgressHighLabel.center = highLabelCenterPoint;
    self.secondaryProgressHighLabel.text = [self.lastSecondaryProgressHighValue stringValue];
    [self addSubview:self.secondaryProgressHighLabel];
    
}

- (UILabel *)newSecondaryProgressLabel {
    UILabel *secondaryProgressLabel = [UILabel new];
    [secondaryProgressLabel setFrame:CGRectMake(0, 0, 80.0f, 16.0f)];
    secondaryProgressLabel.textColor = STCWhiteColor;
    secondaryProgressLabel.font = [UIFont fontWithName:kHelveticaNeueLightFontName size:14.0f];
    secondaryProgressLabel.textAlignment = NSTextAlignmentCenter;
    return secondaryProgressLabel;
}

- (CGPoint)pointOnCircleFromCenter:(CGPoint)centerPoint radius:(float)radius angle:(float)angle {
    float x = centerPoint.x + radius * cosf(angle);
    float y = centerPoint.y + radius * sinf(angle);
    
    return CGPointMake(x, y);
}

- (void)updateViewWithPercent:(NSNumber *)percent{
    if([[NSDate date] timeIntervalSinceDate:_lastUpdated] > 0.2f){
        if(percent != _lastProgressValue){
            [self animateProgressWithValue:percent];
        }
    }else if([percent floatValue] == 0.0 || [percent floatValue] == 1.0){
        [self animateProgressWithValue:percent];
    }
}

- (CGPoint)startPointForBezierPath:(UIBezierPath *)path {

    NSMutableArray *bezierPoints = [NSMutableArray array];
    CGPathApply(path.CGPath, (__bridge void *) bezierPoints, processPathElement);
    return ((NSValue * )bezierPoints[0]).CGPointValue;

}

- (CGPoint) endPointForBezierPath:(UIBezierPath *)path {
    NSMutableArray *bezierPoints = [NSMutableArray array];
    CGPathApply(path.CGPath, (__bridge void *) bezierPoints, processPathElement);
    return ((NSValue * )bezierPoints[bezierPoints.count - 1]).CGPointValue;
}

void processPathElement (void *info, const CGPathElement *element) {
    NSMutableArray *bezierPoints = (__bridge NSMutableArray *)info;
    
    CGPoint *points = element->points;
    CGPathElementType type = element->type;
    
    switch(type) {
        case kCGPathElementMoveToPoint: // contains 1 point
            [bezierPoints addObject:[NSValue valueWithCGPoint:points[0]]];
            break;
            
        case kCGPathElementAddLineToPoint: // contains 1 point
            [bezierPoints addObject:[NSValue valueWithCGPoint:points[0]]];
            break;
            
        case kCGPathElementAddQuadCurveToPoint: // contains 2 points
            [bezierPoints addObject:[NSValue valueWithCGPoint:points[0]]];
            [bezierPoints addObject:[NSValue valueWithCGPoint:points[1]]];
            break;
            
        case kCGPathElementAddCurveToPoint: // contains 3 points
            [bezierPoints addObject:[NSValue valueWithCGPoint:points[0]]];
            [bezierPoints addObject:[NSValue valueWithCGPoint:points[1]]];
            [bezierPoints addObject:[NSValue valueWithCGPoint:points[2]]];
            break;
            
        case kCGPathElementCloseSubpath: // contains no point
            break;
    }
}

- (void)updateViewWithSecondaryProgressLow:(NSNumber *)low high:(NSNumber *)high {

    if(self.secondaryShapeLayer) {
        if([low floatValue] < 0.0f) {
            low = @0.0f;
        }
        
        if([high floatValue] > 1.0f) {
            high = @1.0f;
        }
       
        float lowAngle = 135.0 + [low floatValue] * 270.0;
        float highAngle = 135.0 + [high floatValue] * 270.0;
//         NSLog(@"secondary progress update low: %@, high: %@, lowAngle: %f, highAngle: %f", low, high, lowAngle, highAngle);
        CGRect ovalRect = [self ovalRect];
        
        UIBezierPath *secondaryOvalPath = [UIBezierPath bezierPath];
        [secondaryOvalPath addArcWithCenter:CGPointMake(CGRectGetMidX(ovalRect), CGRectGetMidY(ovalRect)) radius:[self secondaryProgressViewRadius] startAngle:radians(lowAngle) endAngle:radians(highAngle) clockwise:YES];
        
        secondaryOvalPath.lineWidth = 6.0f;
        
        self.secondaryShapeLayer.path = [secondaryOvalPath CGPath];
        [self.secondaryShapeLayer didChangeValueForKey:@"path"];
        
        UIBezierPath *secondaryLabelOvalPath = [UIBezierPath bezierPath];
        [secondaryLabelOvalPath addArcWithCenter:CGPointMake(CGRectGetMidX(ovalRect), CGRectGetMidY(ovalRect)) radius:[self secondaryProgressViewRadius] + 26.0f startAngle:radians(lowAngle) endAngle:radians(highAngle) clockwise:YES];
        
        CGPoint newLowCenterPoint = [self startPointForBezierPath:secondaryLabelOvalPath];
        self.secondaryProgressLowLabel.center = newLowCenterPoint;
        CGRect updatedSecondaryProgressLowLabelRect = self.secondaryProgressLowLabel.frame;
        
        CGPoint newHighCenterPoint = [self endPointForBezierPath:secondaryLabelOvalPath];
        CGRect proposedSecondaryProgressHighLabelRect = self.secondaryProgressHighLabel.frame;
        proposedSecondaryProgressHighLabelRect.origin = CGPointMake(newHighCenterPoint.x - proposedSecondaryProgressHighLabelRect.size.width/2, newHighCenterPoint.y - proposedSecondaryProgressHighLabelRect.size.height/2);
        
        BOOL rectsIntersect = CGRectIntersectsRect (updatedSecondaryProgressLowLabelRect, proposedSecondaryProgressHighLabelRect);
        
        if (!rectsIntersect) {
            self.secondaryProgressHighLabel.center = [self endPointForBezierPath:secondaryLabelOvalPath];
        } else {
            UIBezierPath *secondaryLabelExtendedOvalPath = [UIBezierPath bezierPath];
            [secondaryLabelExtendedOvalPath addArcWithCenter:CGPointMake(CGRectGetMidX(ovalRect), CGRectGetMidY(ovalRect)) radius:[self secondaryProgressLabelRadius] startAngle:radians(lowAngle) endAngle:radians(highAngle + 15.0f) clockwise:YES];
            self.secondaryProgressHighLabel.center = [self endPointForBezierPath:secondaryLabelExtendedOvalPath];
        }
    }
}

- (float)secondaryProgressLabelRadius {
    float progressViewRadius = [self secondaryProgressViewRadius];
    return progressViewRadius + 26.0f;
}

- (float)secondaryProgressViewRadius {
    CGRect ovalRect = [self ovalRect];
    return CGRectGetWidth(ovalRect) / 2.0 + 8.0;
}

- (void)animateProgressWithValue:(NSNumber *)percent{
    
    if (self.raysImageView && ![self.raysImageView isHidden]) {
        [UIView animateWithDuration:0.2 animations:^{
            [self.raysImageView setAlpha:[percent floatValue]];
        }];
    }
    
    if([percent floatValue] < 0.0f)percent = [NSNumber numberWithFloat:0.0f];
    if([percent floatValue] > 1.0f)percent = [NSNumber numberWithFloat:1.0f];
    
    CABasicAnimation *pathAnimation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    [pathAnimation setRemovedOnCompletion:NO];
    [pathAnimation setFillMode:kCAFillModeForwards];
    pathAnimation.duration = 0.2f;
    float fromValuePercent = [_lastProgressValue floatValue];
    float toValuePercent = [percent floatValue];
    
    pathAnimation.fromValue = @(fromValuePercent);
    pathAnimation.toValue = @(toValuePercent);
    //NSLog(@"from percent: %f, to percent: %f", fromValuePercent, toValuePercent);
    [_shapeLayer addAnimation:pathAnimation forKey:@"strokeEnd"];
    
    _lastProgressValue = [NSNumber numberWithFloat:toValuePercent];
    _lastUpdated = [NSDate date];
}

- (void)showSecondaryProgressViews:(BOOL)showProgressViews {
    
    if (self.backgroundSecondaryShapeLayer) {
        [self.backgroundSecondaryShapeLayer setHidden:!showProgressViews];
    }
    
    if (self.secondaryShapeLayer) {
        [self.secondaryShapeLayer setHidden:!showProgressViews];
    }
    
    if (self.secondaryProgressLowLabel) {
        [self.secondaryProgressLowLabel setHidden:!showProgressViews];
    }
    
    if (self.secondaryProgressHighLabel) {
        [self.secondaryProgressHighLabel setHidden:!showProgressViews];
    }
}

#pragma mark - Overrides

- (void)setProgress:(float)progress {
    _progress = progress;
    [self updateViewWithPercent:[STConstants roundFloatNearest2:progress]];
}

- (void) setSecondaryProgressLow:(float)secondaryProgressLow {
    _secondaryProgressLow = secondaryProgressLow;
    if (!self.secondaryShapeLayer) {
        [self setupSecondaryProgressLayer];
    }
    [self updateViewWithSecondaryProgressLow:[STConstants roundFloatNearest2:secondaryProgressLow] high:[STConstants roundFloatNearest2:self.secondaryProgressHigh]];
}

- (void) setSecondaryProgressHigh:(float)secondaryProgressHigh {
    _secondaryProgressHigh = secondaryProgressHigh;
    if (!self.secondaryShapeLayer) {
        [self setupSecondaryProgressLayer];
    }
    [self updateViewWithSecondaryProgressLow:[STConstants roundFloatNearest2:self.secondaryProgressLow] high:[STConstants roundFloatNearest2:secondaryProgressHigh]];
}

@end
