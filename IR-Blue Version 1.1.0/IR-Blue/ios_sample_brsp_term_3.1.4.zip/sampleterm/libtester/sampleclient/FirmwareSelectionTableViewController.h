//
//  FirmwareSelectionTableViewController.h
//  sampleterm
//
//  Created by Neel Pansare on 5/22/14.
//
//

#import <UIKit/UIKit.h>
#import "Brsp.h"
@interface FirmwareSelectionTableViewController : UITableViewController

@property (nonatomic, strong) NSMutableArray *dataSourceFirmwareList;
@property (nonatomic, strong) NSString *currentFirmware;

@end
