//
//  BRLightMeter.h
//  BlueSense
//
//  Created by Phil Beadle on 5/20/13.
//  Copyright (c) 2013 BlueRadios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BRLightMeter : UIView

@property (nonatomic, assign) float progress;
@property (nonatomic, assign) float secondaryProgressLow;
@property (nonatomic, assign) float secondaryProgressHigh;
@property (nonatomic, strong) UILabel *secondaryProgressLowLabel;
@property (nonatomic, strong) UILabel *secondaryProgressHighLabel;

void processPathElement (void *info, const CGPathElement *element);
@end
