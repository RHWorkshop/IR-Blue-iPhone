//
//  FirmwareSelectionTableViewController.m
//  sampleterm
//
//  Created by Neel Pansare on 5/22/14.
//
//

#import "FirmwareSelectionTableViewController.h"
#import "FirmwareUpdateViewController.h"
#import "STConstants.h"
#import "MBProgressHUD.h"

#define kCurrentFirmwareSection 0
#define kUpdateFirmwareListSecion 1
#define kAlertViewCommandModeUnsupported 3

@interface FirmwareSelectionTableViewController ()

@property (nonatomic, strong) NSString *firmwareUpdateFileName;
@property (nonatomic) BOOL didNotifyUserAboutCommandModeUnsupported;

@end

@implementation FirmwareSelectionTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    _dataSourceFirmwareList = [[NSMutableArray alloc] init];
    
    NSString *firmwarePath = [[NSBundle mainBundle] resourcePath];
    NSString* newFileName;
    NSArray *tempArray = [self listFileAtPath:firmwarePath];
    NSInteger fileType;
    
    // Determine the firmware update file type
    if ([_currentFirmware rangeOfString:STCUpdateTYPE_S2].location != NSNotFound) {
        
        fileType = STCUpdateTypeS2;
    } else if ([_currentFirmware rangeOfString:STCUpdateTYPE_S3].location != NSNotFound) {
        
        fileType = STCUpdateTypeS3;
    } else if ([_currentFirmware rangeOfString:STCUpdateTYPE_PAN1720].location != NSNotFound) {
        
        fileType = STCUpdateTypePAN1720;
    } else if ([_currentFirmware rangeOfString:STCUpdateTYPE_PAN1721].location != NSNotFound) {
        
        fileType = STCUpdateTypePAN1721;
    } else {
        
        // Unknown
        fileType = STCUpdateTypeUnknown;
        _currentFirmware = STCFirmwareVersionUnknown;
        [self showAlertUnknownUpdateFileType];
    }
    
    // If command mode is not supported and current firmware type is Unknown show all the available files
    if ([_currentFirmware isEqualToString:STCFirmwareVersionUnknown]) {
        
        for (NSString *fileName in tempArray) {
            
            // If File is .Bru add to tableview
            if (![fileName rangeOfString:STCFileTypeBru].location != NSNotFound) {
                
                newFileName = [fileName stringByDeletingPathExtension];
                [_dataSourceFirmwareList addObject:newFileName];
            }
        }
        
    } else {
        
        // If firmware type and current version is known show list of the rest of the supported versions
        NSString *currentVersionType;
        NSString *versionType;
        
        for (NSString *fileName in tempArray) {
            
            // If File is .Bru add to tableview
            if (![fileName rangeOfString:STCFileTypeBru].location != NSNotFound) {
                
                // If file is the same type as the device version supports Eg. S2 or S3 type
                newFileName = [fileName stringByDeletingPathExtension];
                
                // Determine version type agains S2, S3, PAN1720, PAN1721
                if (fileType == STCUpdateTypeS2 || fileType == STCUpdateTypeS3) {
                    currentVersionType = [self getVersionType: _currentFirmware withRange:NSMakeRange([_currentFirmware length] - 2, 2)];
                    versionType = [self getVersionType:fileName withRange:NSMakeRange([fileName length] - 6, 2)];
                } else if(fileType == STCUpdateTypePAN1720 || fileType == STCUpdateTypePAN1721) {
                    
                    currentVersionType = [self getVersionType: _currentFirmware withRange:NSMakeRange([_currentFirmware length] - 7, 7)];
                    versionType = [self getVersionType:fileName withRange:NSMakeRange([fileName length] - 11, 7)];
                } else {
                    
                    versionType = nil;
                }
                
                
                if ([currentVersionType isEqualToString:versionType]) {
                    
                    // If the current version is the same don't show that file in the tableview
                    if ([fileName rangeOfString:_currentFirmware].location == NSNotFound) {
                        
                        [_dataSourceFirmwareList addObject:newFileName];
                    }
                }
            }
        }
    }
    
    
    self.navigationItem.title = @"Firmware Update";
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStyleBordered target:self action:@selector(backBarButtonTapped:)];
}

- (void) viewDidAppear:(BOOL)animated {

    if ([[AppDelegate app].activePeripheral state] == CBPeripheralStateDisconnected) {
        
        [self.navigationController popViewControllerAnimated:NO];
    }
    
    // If command mode is not supported and current firmware type is Unknown
    if ([_currentFirmware isEqualToString:STCFirmwareVersionUnknown]) {
        if (!_didNotifyUserAboutCommandModeUnsupported) {
            
            [self showAlertCommandModeNotSupported];
        }
    }
}

- (void) viewDidDisappear:(BOOL)animated {
    
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Instance Methods

- (NSString *) getVersionType: (NSString *) fileName withRange: (NSRange) range {
    
    return [fileName substringWithRange:range];
}

- (NSArray *)listFileAtPath:(NSString *)path {
    
    
    NSArray *directoryContent = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:path error:NULL];
    NSMutableArray *bruFileArray = [NSMutableArray new];
    
    [directoryContent enumerateObjectsUsingBlock:^(NSString *fileName, NSUInteger idx, BOOL *stop) {
        
        if ([fileName rangeOfString:STCFileTypeBru].location != NSNotFound) {
            [bruFileArray addObject:fileName];
        }
    }];
    
    return bruFileArray;
}

#pragma mark - TableView data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    switch (section) {
        case kCurrentFirmwareSection: {
            
            return 1;
            break;
        }
            
        case kUpdateFirmwareListSecion:
            
            
            return [_dataSourceFirmwareList count];
            
            break;
    }

    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellIdentifier = @"firmwareCellIdentifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    cell.accessoryView = nil;
    
    
    switch (indexPath.section) {
        case kCurrentFirmwareSection: {
            switch (indexPath.row) {
                case 0:
                    
                    //cell.userInteractionEnabled = NO;
                    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
                    cell.accessoryType = UITableViewCellAccessoryNone;
                    if (_currentFirmware != nil && _currentFirmware.length > 0) {
                        
                        cell.textLabel.text = _currentFirmware;
                    } else {
                        cell.textLabel.text = STCFirmwareVersionUnknown;
                    }
                    
                    cell.detailTextLabel.text = @"";
                    break;
            }
            break;
        }
            
        case kUpdateFirmwareListSecion:
            
            cell.textLabel.text = [_dataSourceFirmwareList objectAtIndex:indexPath.row];
            cell.detailTextLabel.text = @"";
            
            break;
            
            
        default:
            break;
    }
    
    
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    switch (section) {
            
        default:
            return 30.0;
            break;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    switch (section) {
            
        case kCurrentFirmwareSection:
            return @"Current Firmware:";
            break;
        case kUpdateFirmwareListSecion:
            return @"Update To:";
            break;
        default:
            return nil;
            break;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    switch (indexPath.section) {

        case kUpdateFirmwareListSecion:
            
            _firmwareUpdateFileName = [_dataSourceFirmwareList objectAtIndex:[indexPath row]];
            [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
            [self performSegueWithIdentifier:@"segueUpdateFirmware" sender:self];
            break;
            
        default:
            break;
    }
}

// In a story board-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([[segue identifier] isEqualToString:@"segueUpdateFirmware"]) {
        
        FirmwareUpdateViewController *firmwareUpdateViewController = [segue destinationViewController];
        firmwareUpdateViewController.firmwareUpdateFileName = _firmwareUpdateFileName;
        firmwareUpdateViewController.currentlyInstalledFirmware = _currentFirmware;
    }
}

#pragma mark - IBActions
- (void) backBarButtonTapped:(id)sender {

    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - AlerView

- (void)showAlertUnknownUpdateFileType
{
    _didNotifyUserAboutCommandModeUnsupported = YES;
    double delayInSeconds = 1.0;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC)); // 1
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){ // 2
        
        UIAlertView *alertUnknownUpdateFileType = [[UIAlertView alloc] initWithTitle:@"Warning!"
                                                                             message:@"Firmware Type not recognized, please select the appropriate option from the list."
                                                                            delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alertUnknownUpdateFileType show];
    });
}

- (void) showAlertCommandModeNotSupported {
    
    _didNotifyUserAboutCommandModeUnsupported = YES;
    UIAlertView *alertCommandModeUnsupported = [[UIAlertView alloc] initWithTitle:@"Warning!"
                                                                          message:@"Remote command mode is not supported so the module type could not be detected.  Make sure the proper firmware is selected for the module (S2 vs S3)."
                                                                         delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    alertCommandModeUnsupported.tag = kAlertViewCommandModeUnsupported;
    [alertCommandModeUnsupported show];
}

@end
