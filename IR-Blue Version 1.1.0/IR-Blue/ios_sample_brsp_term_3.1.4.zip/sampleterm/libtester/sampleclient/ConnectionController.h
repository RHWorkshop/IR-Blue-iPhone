//
//  ConnectionController.h
//  sampleterm
//
//  Created by Michael Testa on 11/1/12.
//  Copyright (c) Blueradios, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "Brsp.h"
#import "BrspManager.h"
#import "MBProgressHUD.h"

@interface ConnectionController : UIViewController <UITextFieldDelegate, BrspManagerDelegate, CBCentralManagerDelegate> {
    UITextField *_inputText;
    NSMutableString *_outputText;   //used as string data for textView to make string concatenations more efficient
    NSArray *_allCommands;          //All commands sent by the get settings button
    NSMutableArray *_commandQueue;  //An array of commands queued for sending
    BrspMode _lastMode;
    
    //debug stuff for timing and displaying byte count and time taken
    int _byteCount;
    NSTimeInterval _debugStartTime;
    NSTimer *_debugTimer;
    NSTimer *_scrollTimer;
    NSTimer *_outputTimer;
    MBProgressHUD *_hud;
}

@property (strong, nonatomic) IBOutlet UITextView *textView;
@property (strong, nonatomic) IBOutlet UITextField *inputText;

@property (nonatomic) int totalSent;
@property (strong, nonatomic) IBOutlet UIButton *buttonChangeMode;
@property (strong, nonatomic) IBOutlet UIButton *buttonClear;
@property (strong, nonatomic) IBOutlet UIButton *buttonLeft;

@property (strong, nonatomic) IBOutlet UILabel *labelByteCount;
@property (strong, nonatomic) IBOutlet UILabel *labelTimeTaken;

@property (nonatomic, strong) NSString *firmwareVersionOutput;
@property (nonatomic) BOOL isFirmwareVersionInquiry;
@property (nonatomic, strong) NSTimer *connectionTimer;

@property (nonatomic) BOOL isIntentionalDisconnect;

- (IBAction)changeMode:(id)sender;
- (void)animateTextField:(UITextField*)textField up:(BOOL)up;

- (void)enableButtons;
- (void)disableButtons;
- (void)enableButton:(UIButton*)butt;
- (void)disableButton:(UIButton*)butt;

- (void)outputToScreen:(NSString *)str;
- (void)sendCommand:(NSString *)str;
- (NSString*)parseFullCommandResponse;
- (NSString*)parseCommandData:(NSString*)fullCommandResponse;
- (void)outputCommandWithResponse:(NSString*)response;

@end
