//
//  AlertviewManager.m
//  sampleterm
//
//  Created by Neel Pansare on 6/17/14.
//
//

#import "AlertviewManager.h"
#import "AppDelegate.h"

@implementation AlertviewManager

- (id)init {

    return self;
}

+ (AlertviewManager *)sharedInstance {
    static dispatch_once_t once;
    static AlertviewManager * sharedInstance; dispatch_once(&once, ^{
        sharedInstance = [[self alloc] init]; });
    return sharedInstance;
}

- (void) showAlertUpdateSucceeded {
    
    UIAlertView *alertSuccess = [[UIAlertView alloc] initWithTitle:@"Update Complete!" message:@"Firmware Update Succeeded!" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
    alertSuccess.tag = kAlertFirmwareUpdateResult;
    [alertSuccess show];
}

- (void) showAlertUpdateFailed {
    
    UIAlertView *alertFailure = [[UIAlertView alloc] initWithTitle:@"Update Failed!" message:@"Firmware Update Failed! Please try again." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
    alertFailure.tag = kAlertFactoryReset;
    [alertFailure show];
}

- (void) showAlertDisconnectedDevice {
    
    UIAlertView *alertUpdateFailed = [[UIAlertView alloc] initWithTitle:@"Update Failed" message:@"Device connection lost. Device needs to be reconnected." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
    alertUpdateFailed.tag = kAlertViewDisconectedDevice;
    [alertUpdateFailed show];
}

- (void) showAlertFirmwareNotFound {
    
    UIAlertView *alertFaileure = [[UIAlertView alloc] initWithTitle:@"Update Failed!" message:@"Couldn't find the requested firmware." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alertFaileure show];
}


#pragma mark - UIAlertView Delegate Methods

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    
    switch (alertView.tag) {
            
        case kAlertViewDisconectedDevice:
            
            [[AppDelegate app].cbCentral cancelPeripheralConnection:[AppDelegate app].activePeripheral];
            break;
            
        default:
            break;
    }
}


@end
