//
//  Utilities.m
//  nBlue
//
//  Created by Michael Testa on 3/7/12.
//  Copyright (c) 2012 BlueRadios, Inc. All rights reserved.
//

#import "Utilities.h"

//CBUUID to string category
@interface CBUUID (StringExtraction)

- (NSString *)representativeString;

@end

@implementation CBUUID (StringExtraction)

- (NSString *)representativeString;
{
    NSData *data = [self data];
    
    NSUInteger bytesToConvert = [data length];
    const unsigned char *uuidBytes = [data bytes];
    NSMutableString *outputString = [NSMutableString stringWithCapacity:16];
    
    for (NSUInteger currentByteIndex = 0; currentByteIndex < bytesToConvert; currentByteIndex++)
    {
        switch (currentByteIndex)
        {
            case 3:
            case 5:
            case 7:
            case 9:[outputString appendFormat:@"%02x-", uuidBytes[currentByteIndex]]; break;
            default:[outputString appendFormat:@"%02x", uuidBytes[currentByteIndex]];
        }
        
    }
    
    return outputString;
}

@end

@implementation Util
+ (NSString*)osVersion {
	return [UIDevice currentDevice].systemVersion;
}

//Returns YES if the OS is == or greater than the passed in argument.  EX: [Util isAtLeastVersion:@"3.2"]
//Used for checking if the users OS supports 128 bit characteristics
+ (BOOL)isAtLeastVersion:(NSString*)version {
	if ([[Util osVersion] compare:version options:NSNumericSearch] != NSOrderedAscending)
		return YES;
	
	return NO;
}

+ (CBService*)findService:(CBUUID*)uuid InPeripheral:(CBPeripheral*)peripheral {
    CBService *service = nil;
    if (uuid)
        for (CBService *s in peripheral.services) {
            if ([uuid isEqual:s.UUID]) {
                service = s;
                break;
            }
        }
    if (!service) //Service not found on this peripheral
        printf("Warning: Could not find BRSP service on peripheral with UUID %s\r\n", [[Util UUIDRefToNSString:peripheral.UUID] UTF8String]);
    return service;
}

+ (CBCharacteristic*) findCharacteristic:(CBUUID *)uuid InService:(CBService*)service {
    CBCharacteristic *characteristic = nil;
//    NSLog(@"Service count %d", service.characteristics.count);
//    for (CBCharacteristic *ch in service.characteristics) {
//        NSLog(@"%@", [ch.UUID representativeString]);
//    }
    if (uuid)
        for (CBCharacteristic *c in service.characteristics) {
            if ([uuid isEqual:c.UUID]) {
//                NSLog(@"Found BRSP characteristic: %@ for service UUID %s\r\n",[uuid representativeString], [service.UUID.description UTF8String]);
                characteristic = c;
                break;
            }
        }
    if (!characteristic) //Characteristic not found on this service
        NSLog(@"Warning: Could not find a required BRSP characteristic: %@ for service UUID %s\r\n",[uuid representativeString], [service.UUID.description UTF8String]);
    return characteristic;
}

//Maybe not want ot use this
//+ (const char *) UUIDRefToString:(CFUUIDRef)UUID {
//    if (!UUID) return "NULL";
//    CFStringRef s = CFUUIDCreateString(NULL, UUID);
//    return CFStringGetCStringPtr(s, 0);
//}

+ (NSString*) UUIDRefToNSString:(CFUUIDRef)uuidref {
    CFStringRef string = CFUUIDCreateString(NULL, uuidref);
    return (__bridge_transfer NSString *)string;
}

+ (BOOL) isConnected:(CBPeripheral*)peripheral {
    BOOL isAtLeast7 = [[Util osVersion] floatValue] >= 7.0;
    if (isAtLeast7) {
        return (peripheral.state == 1 || peripheral.state == 2);
    } else {
        return peripheral.isConnected;
    }
}

@end