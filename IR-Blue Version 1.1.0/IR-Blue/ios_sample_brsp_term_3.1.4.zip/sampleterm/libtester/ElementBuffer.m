//
//  ByteBuffer.m
//  ios_brsp
//
//  Created by Michael Testa on 11/6/12.
//  Copyright (c) 2012 BlueRadios, Inc. All rights reserved.
//

#import "ElementBuffer.h"

#define DEFAULT_BUFFER_SIZE 1024

static const size_t ELEMENT_SIZE_BYTE = 1;

//TODO: In the future.  Put a tail in here to make it more efficient

@interface ElementBuffer() {
    size_t _size;               /* total size of buffer in bytes    */
    size_t _elementSize;        /* size of a single element         */
    size_t _start;              /* index of oldest element (head)   */
    size_t _readableCount;      /* readable element count           */
    unsigned char *_elements;   /* vector of elements               */
}
//Initializes the member variables of this class
-(void)initVariables;
//Frees memory and puts object in an uninitialized state
-(void)reset;

@end

@implementation ElementBuffer

-(void)dealloc {
    [self reset];
}

-(id) init {
    self = [super init];
    if (self) {
        [self reset];
        [self initVariables];
    }
    return self;
}

-(id) initWithSize:(size_t)size ElementSize:(size_t)elementSize {
    if (size < 1 || size < elementSize)
        return nil; //invalid arguments
    self = [super init];
    if (self) {
        [self reset];
        _size = size;
        _elementSize = elementSize;
        _elements = (unsigned char *)malloc(_size);
        [self initVariables];
    }
    return self;
}

-(void)initVariables {
    //Init defaults if they are not defined already
    _start = 0;
    _readableCount = 0;
    if (_elementSize == 0)
        _elementSize = 1;
    if (_size == 0)
        _size = DEFAULT_BUFFER_SIZE;
    if (_elements == nil)
        _elements = (unsigned char *)malloc(_size);
}

-(void)reset {
    _size = 0;
    _elementSize = 0;
    _start = 0;
    _readableCount = 0;
    if(_elements != nil)
    {
        free(_elements);
        _elements = nil;
    }
}

-(size_t)size {
    return _size;
}
-(size_t)elementSize {
    return _elementSize;
}
-(size_t)elementCount {
    return (_size / _elementSize);
}
-(size_t)readableElementCount {
    return (_readableCount);
}
-(size_t)availableElements {
    return ((_size / _elementSize) - _readableCount);
}
-(size_t)availableBytes {
    return (_size - (_readableCount * _elementSize));
}

-(NSData*) peek:(size_t)elementCount {
    if (self.readableElementCount == 0)
        return nil;
    if (elementCount > self.readableElementCount)
        elementCount = self.readableElementCount;
    NSData *data;
    size_t dataLength = _elementSize * elementCount;
    
    data = [self readData:dataLength];
    return data;
}

-(NSData*) read:(size_t)elementCount {
    NSData *data = [self peek:elementCount];
    if (data)
        //peek read some data, move pointer and set varaibles
        [self remove:elementCount];
    return data;
}

-(BOOL) write:(NSData*)data {
    if (data.length > self.availableBytes)
        return NO; //Write failed.  Too large
    size_t writeStart = (_start + _readableCount * _elementSize) % _size;
    size_t writeEnd = (writeStart + data.length) % _size;
    
    [self writeData:data Start:writeStart End:writeEnd];   
    _readableCount += data.length / _elementSize;
    return YES;
}

-(BOOL) remove:(size_t)elementCount {
    //Force remove of all readable elements if elementCount > readableElements
    if (elementCount > self.readableElementCount)
        elementCount = self.readableElementCount;
    BOOL returnValue = NO;
    if (_readableCount >= elementCount)
    {
        _start = (_start + elementCount * _elementSize) % _size;
        _readableCount -= elementCount;
        returnValue = YES;
    }
    return returnValue;
}

//Writes data to 1 contiguous or 2 non-contiguous parts of memory (_elements[]) dependant on end less than start
//Do not call this function if (data.length > self.availableBytes)
-(void)writeData:(NSData*)data Start:(size_t)writeStart End:(size_t)writeEnd {
    if (writeEnd < writeStart)
    {
        //non-contiguous write.  2 writes needed
        NSRange range1 = NSMakeRange(0, _size - writeStart);
        NSRange range2 = NSMakeRange(_size - writeStart, writeEnd);
        [data getBytes:&_elements[writeStart] range:range1];
        [data getBytes:&_elements[0] range:range2];
    } else {
        //contiguous write.  Only 1 write needed
        [data getBytes:&_elements[writeStart] length:data.length];
    }
}

//Reads data from 1 contiguous or 2 non-contiguous parts of memory (_elements[]) dependant on end less than start
-(NSData*)readData:(size_t)byteCount {
    if ((_start + byteCount) > _size)
    {
        //non-contiguous read
        NSMutableData *data = [NSMutableData dataWithBytes:&_elements[_start] length:(_size - _start)];
        [data appendBytes:&_elements[0] length:(byteCount - data.length)];
        return [NSData dataWithData:data];
    } else {
        //contiguous read
        return [NSData dataWithBytes:&_elements[_start] length:byteCount];
    }
}

@end
