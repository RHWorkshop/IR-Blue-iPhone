//
//  ByteBuffer.h
//  ios_brsp
//
//  Created by Michael Testa on 11/6/12.
//  Copyright (c) 2012 BlueRadios, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

//Class is essentially a byte queue made up of single or multibyte element lengths
// To use this as a bytebuffer use either "init" or "initWithSize:N ElementSize:1"
@interface ElementBuffer : NSObject {
}

//Total size of the buffer in bytes
@property (nonatomic, readonly) size_t size;
//Size of an element
@property (nonatomic, readonly) size_t elementSize;
//Total number of elements that can fit in the buffer
@property (nonatomic, readonly) size_t elementCount;
//Readable elements in the buffer
@property (nonatomic, readonly) size_t readableElementCount;
//Total number of elements that can currently be written to the buffer
@property (nonatomic, readonly) size_t availableElements;
//Total number of bytes that can currently be written to the buffer
@property (nonatomic, readonly) size_t availableBytes;

//Works like a read without removing elements from buffer
-(NSData*) peek:(size_t)elementCount;
//Reads the number of elements and removes them from the buffer.
//If elementcount greater than available elements, will return all avalable data
//If empty will return nil
-(NSData*) read:(size_t)elementCount;
//Push data into the buffer.  Yes == success
-(BOOL) write:(NSData*)data;
//Removes the number of elements from the buffer. Will remove all avalable data if elementCount > readableElementCount
//Returns YES if successful
-(BOOL) remove:(size_t)elementCount;

//Initializes with a set size and elementSize
//If init is used instead, the default size is 1024 bytes with an element size of 1
//Will not initialize (return null) if elementSize > size
-(id) initWithSize:(size_t)size ElementSize:(size_t)elementSize;

@end
