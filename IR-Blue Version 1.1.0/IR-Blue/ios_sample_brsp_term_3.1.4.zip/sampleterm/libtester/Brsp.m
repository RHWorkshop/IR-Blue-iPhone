//
//  Brsp.m
//  ios_brsp_lib
//
//  Created by Michael Testa on 11/1/12.
//  Copyright (c) 2012 BlueRadios, Inc. All rights reserved.
//

#import "Brsp.h"
#import "Utilities.h"
#import "ElementBuffer.h"


#define kFirmwareSupportValue7 7
#define kFirmwareSupportValue5 5

//TODO: In future fast communication will have to be coded for without response using credits

//How many services BRSP contains.  Here for posible additional future services
#define BRSP_SERVICE_COUNT 1
//Size of a packet
#define BLE_PACKET_SIZE 20

//Static variable to ensure globals only get initialized once per application
static BOOL globalsInitialized = NO;
//An NSDictionary characteristic filter NSArrays with CBUUID service keys
//Only 1 service for BRSP for now
static NSDictionary *serviceCharacteristicArrays;

static NSString *BRSP_INFO_UUID;
static NSString *BRSP_MODE_UUID;
static NSString *BRSP_RX_UUID;
static NSString *BRSP_TX_UUID;
static NSString *BRSP_CTS_UUID;
static NSString *BRSP_RTS_UUID;

@interface Brsp() {
    BrspMode _currentMode;
    CBPeripheral *_activePeripheral;
    NSInteger _serviceDiscoveryCount; //Only will be used if more services are added to BRSP
    NSInteger _lastRTS; //If 0 Clear to Send
    NSUInteger _lastByteCountSent;  //Used to remove only the byte count sent last time and not more (Peek and Remove)
    //Used with writeWithResponse mode
    //YES if a write was sent and no response has come back yet. NO when the last response is received
    //This flag is used to prevent a write without receiving a response for the previous write
    BOOL _alreadySending;
    
    ElementBuffer *_inputBuffer;
    ElementBuffer *_outputBuffer;
    NSUInteger _securityLevel;
    
    BOOL _isOpen;
    
    NSTimer *_delayTimer;
    NSTimer *_restartDelayTimer;
}

//Timers used in hack for setting CTS
-(void)delayUsingCTS:(NSTimer *)timer;
-(void)restartDelay:(NSTimer *)timer;

//Reads a charcteristic of the BRSP service
-(void) readCharacteristic:(NSString*)characteristicString ForService:(NSString*)serviceString;
//Writes a charcteristic of the BRSP service
-(void)writeCharacteristic:(NSString*)characteristicString ForService:(NSString*)serviceString Value:(NSData*)data;
-(void)enableNotification:(CBUUID *)serviceUUID characteristicUUID:(CBUUID *)characteristicUUID Enabled:(BOOL)enabled;

//---Validation---
//Returns an error if _active peripheral is null or closed
-(NSError*) invalidPeripheral;
//Returns an error if invalid peripheral or writebuffer not large enough for request
-(NSError*) writeRequestHasError:(NSUInteger)writeByteCount;
//Returns an error if the mode change is invalid
-(NSError*) invalidModeChange:(BrspMode)newMode;

//Initializes the global static variables used by all instances for this application
-(void)initVariables;
-(void) retrieveAllCharacteristics;
//Send the next packet in the output buffer if not empty
//This is safe to call multiple times and will only allow one write before a response is received
-(void)sendPacket;

@end

@implementation Brsp

@synthesize delegate;
@synthesize brspMode = _currentMode;
@synthesize peripheral = _activePeripheral;
@synthesize securityLevel = _securityLevel;
@synthesize isFirmwareUpdateModeSupported = _isFirmwareUpdateModeSupported;
@synthesize isOpen = _isOpen;

+ (CBUUID *) brspServiceUUID {
    static CBUUID *serviceUUID;
    
    if(serviceUUID == nil)
        serviceUUID = [CBUUID UUIDWithString:BRSP_SERVICE_UUID];

    return serviceUUID;
}

- (id) init {
    [NSException raise:@"Invalid Class Initialization"
                format:@"-init is not a valid initializer for the %@ class. Use the initWithPeripheral: method instead.", [self class]];
    return nil;
}

#pragma mark Properties

-(NSUInteger) inputBufferCount {
    return (_inputBuffer.readableElementCount * _inputBuffer.elementSize);
}
-(NSUInteger) outputBufferCount {
    return (_outputBuffer.readableElementCount * _outputBuffer.elementSize);
}
-(NSUInteger) inputBufferSize {
    return _inputBuffer.size;
}
-(NSUInteger) outputBufferSize {
    return _outputBuffer.size;
}
-(NSUInteger) outputBufferAvailableBytes {
    return _outputBuffer.availableBytes;
}
-(BOOL)isSending {
    return (_outputBuffer.readableElementCount > 0);
}

#pragma mark CBPeripheralDelegate

- (void)peripheralDidUpdateName:(CBPeripheral *)peripheral NS_AVAILABLE(NA, 6_0) {
//    DebugLog(@"peripheralDidUpdateName called");
}
- (void)peripheralDidInvalidateServices:(CBPeripheral *)peripheral NS_AVAILABLE(NA, 6_0) {
//    DebugLog(@"peripheralDidInvalidateServices called");    
}
- (void)peripheralDidUpdateRSSI:(CBPeripheral *)peripheral error:(NSError *)error {
//    DebugLog(@"peripheralDidUpdateRSSI called");    
}
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error {
    //DebugLog(@"didDiscoverServices called");
    if (!error)
    {
//        DebugLog(@"Services of peripheral with UUID : %@ found.",[Util UUIDRefToNSString:peripheral.UUID]);
        [self retrieveAllCharacteristics];
    }
    else {
        if (self.delegate && [self.delegate respondsToSelector:@selector(brsp:ErrorReceived:)])
            [self.delegate brsp:self ErrorReceived:error];

        printf("Service discovery was unsuccessfull !\r\n");
    }
}
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverIncludedServicesForService:(CBService *)service error:(NSError *)error {
//    DebugLog(@"didDiscoverIncludedServicesForService called");
}
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error {
//    DebugLog(@"didDiscoverCharacteristicsForService called");
    if (!error) {
        ++_serviceDiscoveryCount;

        //If this is the BRSP service.  Change mode and turn on notifications
        if ([service.UUID isEqual:[CBUUID UUIDWithString:BRSP_SERVICE_UUID]])
        {
            //Enable notifications for service
            [self enableNotification:[CBUUID UUIDWithString:BRSP_SERVICE_UUID] characteristicUUID:[CBUUID UUIDWithString:BRSP_TX_UUID] Enabled:YES];
            [self enableNotification:[CBUUID UUIDWithString:BRSP_SERVICE_UUID] characteristicUUID:[CBUUID UUIDWithString:BRSP_RTS_UUID] Enabled:YES];            
        }

        //Finished discovering all characteristics
        if (_serviceDiscoveryCount == BRSP_SERVICE_COUNT)
        {
//            DebugLog(@"Finished discovering BRSP characteristics");
            _serviceDiscoveryCount = 0; //reset for subsequent connects
            [self readCharacteristic:BRSP_INFO_UUID ForService:BRSP_SERVICE_UUID];
        }
    }
    else {
        _serviceDiscoveryCount = 0; //reset for subsequent connects
        if (self.delegate && [self.delegate respondsToSelector:@selector(brsp:ErrorReceived:)])
            [self.delegate brsp:self ErrorReceived:error];
        printf("Characteristic discorvery unsuccessfull !\r\n");
    }
}
- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
    //DebugLog(@"didUpdateValueForCharacteristic called for %@", characteristic.UUID.description);
    if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:BRSP_TX_UUID]]) {
//        if (_inputBuffer.availableBytes < 100) {
//            NSLog(@"Inputbuffer almost full!");
//        }
        [_inputBuffer write:characteristic.value];
        if (self.delegate && [self.delegate respondsToSelector:@selector(brspDataReceived:)])
            [self.delegate brspDataReceived:self];
    } else if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:BRSP_RTS_UUID]]) {
        //Patch VDD to CTS on dev Board to test this
        char tmp;
        [characteristic.value getBytes:&tmp length:1];
        _lastRTS = tmp;
        NSLog(@"Last RTS changed to %d", _lastRTS);
        _alreadySending = NO;
        [self sendPacket];
    } else if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:BRSP_INFO_UUID]]) {
        
        NSUInteger tempInt = 0;
        
        //Populate if the Brsp Firmware update mode is supported
        if (characteristic.value.length == 17) {
            
            [characteristic.value getBytes:&tempInt range:NSMakeRange(0, 1)];
            
            if (tempInt == kFirmwareSupportValue7 || tempInt == kFirmwareSupportValue5) {
                _isFirmwareUpdateModeSupported = YES;
            }
            
            
        }
        
        //Populate security property
        if (characteristic.value.length == 17) {
            
            [characteristic.value getBytes:&_securityLevel range:NSMakeRange(1, 1)];
            
        }
     

        if (self.brspMode != BrspModeData && self.brspMode != BrspModeFirmwareUpdate)
            [self changeBrspMode:BrspModeData];
        //This is the last thing to do to setup brsp service.  Set isOpen to YES and fire delegate
        _isOpen = YES;
        if (self.delegate && [self.delegate respondsToSelector:@selector(brsp:OpenStatusChanged:)])
            [self.delegate brsp:self OpenStatusChanged:_isOpen];
        
        //Delay for 1 second ever 100 milliseconds
        //_delayTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(delayUsingCTS:) userInfo:nil repeats:NO];
    }
    if (error) {
        //Error occurred
        printf("Error receiving response.  Error = %s\r\n", [error.description UTF8String]);
        if (self.delegate && [self.delegate respondsToSelector:@selector(brsp:ErrorReceived:)])
            [self.delegate brsp:self ErrorReceived:error];
    }
}
- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
    _alreadySending = NO;
    if (error) {
        printf("Error writing to peripheral");
//        DebugLog(@"didWriteValueForCharacteristic called with error %@", error.description);
    } else if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:BRSP_RX_UUID]]) {
        [_outputBuffer remove:_lastByteCountSent];  //Successful, remove from buffer
        if (_outputBuffer.readableElementCount == 0)
            //Fire delegate for isSending Changed
            if (self.delegate && [self.delegate respondsToSelector:@selector(brsp:SendingStatusChanged:)])
                [self.delegate brsp:self SendingStatusChanged:self.isSending];

        [self sendPacket];
    }
}
- (void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
    if (!error) {
        if (characteristic.isNotifying) {
        }
    }
    else {
        if (self.delegate && [self.delegate respondsToSelector:@selector(brsp:ErrorReceived:)])
            [self.delegate brsp:self ErrorReceived:error];
    }
}
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverDescriptorsForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
//    DebugLog(@"didDiscoverDescriptorsForCharacteristic called");
}
- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForDescriptor:(CBDescriptor *)descriptor error:(NSError *)error {
//    DebugLog(@"didUpdateValueForDescriptor called");    
}
- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForDescriptor:(CBDescriptor *)descriptor error:(NSError *)error {
//    DebugLog(@"didUpdateValueForDescriptor called");    
}
//Gets all characteristics needed by a brsp peripheral
- (void) retrieveAllCharacteristics {
    NSArray *serviceUUIDs = (NSArray*)[serviceCharacteristicArrays allKeys];
    for (CBService *service in _activePeripheral.services) {
        //Fetch all characteristics only for BRSP
        if ([serviceUUIDs containsObject:service.UUID]) {
            //Prevent a request if this object isn't responding to cbPeripheralDelegate events
            if (_activePeripheral.delegate == self)
                [_activePeripheral discoverCharacteristics:nil forService:service]; //Not filtering by characteristics (get all)
//            [_activePeripheral discoverCharacteristics:[serviceCharacteristicArrays objectForKey:service.UUID] forService:service];
//            DebugLog(@"Fetching characteristics for service with UUID : %@", service.UUID.description);
        }
    }
}

//A hack to delay the recieve for 1 second every millisecond to get the Dual modes working
-(void)delayUsingCTS:(NSTimer *)timer {
    int i = 1;
    NSData *d = [[NSData alloc] initWithBytes:&i length:1];
    [self writeCharacteristic:BRSP_CTS_UUID ForService:BRSP_SERVICE_UUID Value:d];
    [_delayTimer invalidate];
    _restartDelayTimer = [NSTimer scheduledTimerWithTimeInterval:0.001 target:self selector:@selector(restartDelay:) userInfo:nil repeats:NO];
}

-(void)restartDelay:(NSTimer *)timer {
    int i = 0;
    NSData *d = [[NSData alloc] initWithBytes:&i length:1];
    [_restartDelayTimer invalidate];
    _delayTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(delayUsingCTS:) userInfo:nil repeats:NO];
    [self writeCharacteristic:BRSP_CTS_UUID ForService:BRSP_SERVICE_UUID Value:d];
}

#pragma mark Public Class Methods
-(id) initWithPeripheral:(CBPeripheral*)peripheral {
    self = [super init];
    if (self) {
        [self initVariables];
        _activePeripheral = peripheral;
        //Initialize all Vaiables
        _inputBuffer = [ElementBuffer new];
        _outputBuffer = [ElementBuffer new];
    }
    return self;
}

-(id)initWithPeripheral:(CBPeripheral*)peripheral InputBufferSize:(NSUInteger)in_size OutputBufferSize:(NSUInteger)out_size {
    self = [super init];
    if (self) {
        [self initVariables]; 
        _activePeripheral = peripheral;
        //Initialize all Vaiables
        _inputBuffer = [[ElementBuffer alloc] initWithSize:in_size ElementSize:1];
        _outputBuffer = [[ElementBuffer alloc] initWithSize:out_size ElementSize:1];
    }
    return self;
}

- (NSError*)changeBrspMode:(BrspMode)mode {
    NSError *error = [self invalidModeChange:mode];
    if (error)
        return error;
    
    NSData *d = [[NSData alloc] initWithBytes:&mode length:1];
    [self writeCharacteristic:BRSP_MODE_UUID ForService:BRSP_SERVICE_UUID Value:d];
    _currentMode = mode;
    if (self.delegate && [self.delegate respondsToSelector:@selector(brspModeChanged:BRSPMode:)])
        [self.delegate brspModeChanged:self BRSPMode:_currentMode];
    return nil;
}

-(NSError*) writeString:(NSString*)str {
    return [self writeBytes:[str dataUsingEncoding:NSUTF8StringEncoding]];
}

-(NSError*)writeBytes:(NSData *)bytes {
    //Validate
    NSError *error = [self writeRequestHasError:bytes.length];
    if (error)
        return error;
    if (_outputBuffer.readableElementCount == 0)
        _alreadySending = NO; //Reset to start sending again
    //Write Buffer
    [_outputBuffer write:bytes];
    if (bytes.length == _outputBuffer.readableElementCount)
        //Fire delegate for isSending Changed
        if (self.delegate && [self.delegate respondsToSelector:@selector(brsp:SendingStatusChanged:)])
            [self.delegate brsp:self SendingStatusChanged:self.isSending];

    //Send packet
    [self sendPacket];
    return nil;
}

-(NSError*) invalidPeripheral {
    NSError *error = nil;
    NSString *errorString = @"";
    if (_activePeripheral == nil) {
        errorString = @"Error: Action not possible with a null peripheral.  Call init with a valid peripheral object.";
        error = [NSError errorWithDomain:@"Brsp" code:99 userInfo:[NSDictionary dictionaryWithObject:errorString forKey:NSLocalizedDescriptionKey]];
        printf("%s\r\n", [errorString UTF8String]);
    } else if (![Util isConnected:_activePeripheral]) {
        errorString = @"Error: Action not possible with a disconnected peripheral.  Connect and try again.";
        error = [NSError errorWithDomain:@"Brsp" code:100 userInfo:[NSDictionary dictionaryWithObject:errorString forKey:NSLocalizedDescriptionKey]];
        printf("%s\r\n", [errorString UTF8String]);
    }
    return error;
}

-(NSError*) writeRequestHasError:(NSUInteger)writeByteCount {
    NSError *error = [self invalidPeripheral];
    NSString *errorString = @"";
    if (error)
        return error;
    else if (!self.isOpen) {
        errorString = @"Error: Write not possible with Brsp.isOpen status of NO. Brsp.open must be called prior to writes";
        error = [NSError errorWithDomain:@"Brsp" code:101 userInfo:[NSDictionary dictionaryWithObject:errorString forKey:NSLocalizedDescriptionKey]];
        printf("%s\r\n", [errorString UTF8String]);
    } else if (_outputBuffer.availableBytes < writeByteCount) {
        errorString = @"Error: Write not possible. Sent bytes too large to fit in output buffer.";
        error = [NSError errorWithDomain:@"Brsp" code:102 userInfo:[NSDictionary dictionaryWithObject:errorString forKey:NSLocalizedDescriptionKey]];
        printf("%s\r\n", [errorString UTF8String]);
    }
    return error;
}

-(NSError*) invalidModeChange:(BrspMode)newMode {
    NSError *error = [self invalidPeripheral];
    NSString *errorString = @"";
    if (error)
        return error;
    else if (_currentMode == newMode) {
        errorString = [NSString stringWithFormat:@"Warning: Mode already == %d.  Mode not changed.", newMode];
        error = [NSError errorWithDomain:@"Brsp" code:103 userInfo:[NSDictionary dictionaryWithObject:errorString forKey:NSLocalizedDescriptionKey]];
        printf("%s\r\n", [errorString UTF8String]);
    } else if (_outputBuffer.readableElementCount != 0) {
        errorString = @"Error: Can not change mode when output buffer is not empty.  Wait for SendingStatusChanged delegate event or check isSending == NO";
        error = [NSError errorWithDomain:@"Brsp" code:102 userInfo:[NSDictionary dictionaryWithObject:errorString forKey:NSLocalizedDescriptionKey]];
        printf("%s\r\n", [errorString UTF8String]);
    }
    return error;
}

//Sends a packet to the target peripheral, if output buffer populated
-(void)sendPacket {
    //Only send one packet per response
    if (_alreadySending)
        return;
    if (_outputBuffer.readableElementCount > 0)
    {
        _alreadySending = YES;
        NSData *data = [_outputBuffer peek:BLE_PACKET_SIZE];
        if (data != nil) {
            _lastByteCountSent = data.length;
            if (_lastRTS == 0) //It's clear to send.  Send another packet
                [self writeCharacteristic:BRSP_RX_UUID ForService:BRSP_SERVICE_UUID Value:data];
        }
    }
}

-(void) open {
    NSError *error = [self invalidPeripheral];
    if (!error) {
        _activePeripheral.delegate = self;
        //Prevent a request if this object isn't responding to cbPeripheralDelegate events
        if (_activePeripheral.delegate == self)
            [_activePeripheral discoverServices:[serviceCharacteristicArrays allKeys]];
    } else {
        //Error occurred
        if (self.delegate && [self.delegate respondsToSelector:@selector(brsp:ErrorReceived:)])
            [self.delegate brsp:self ErrorReceived:error];
    }
}

-(void) close {
    //No error response needed here.  Just do nothing if certain conditions are not met
    if ([Util isConnected:_activePeripheral]) {
        //Disable notifications
        [self enableNotification:[CBUUID UUIDWithString:BRSP_SERVICE_UUID] characteristicUUID:[CBUUID UUIDWithString:BRSP_TX_UUID] Enabled:NO];
        [self enableNotification:[CBUUID UUIDWithString:BRSP_SERVICE_UUID] characteristicUUID:[CBUUID UUIDWithString:BRSP_RTS_UUID] Enabled:NO];

        [_restartDelayTimer invalidate];
        [_delayTimer invalidate];
        
    }
    if (self.isOpen) {  //Reset this class
        [self initVariables];
        [_inputBuffer remove:_inputBuffer.size];
        [_outputBuffer remove:_outputBuffer.size];
        if (self.delegate && [self.delegate respondsToSelector:@selector(brsp:OpenStatusChanged:)])
            [self.delegate brsp:self OpenStatusChanged:_isOpen];
    }
}

- (void)flushInputBuffer {
    [_inputBuffer remove:_inputBuffer.readableElementCount];
}

- (void)flushInputBuffer:(NSUInteger)byteCount {
    [_inputBuffer remove:byteCount];
}

- (void)flushOutputBuffer {
    BOOL sendingStatusChanged = (_outputBuffer.readableElementCount > 0);
    [_outputBuffer remove:_outputBuffer.readableElementCount];
    if (sendingStatusChanged)
        //Fire delegate for isSending Changed
        if (self.delegate && [self.delegate respondsToSelector:@selector(brsp:SendingStatusChanged:)])
            [self.delegate brsp:self SendingStatusChanged:self.isSending];
}

- (NSData *)peekBytes:(NSUInteger)byteCount {
    return [_inputBuffer peek:byteCount];
}

- (NSString *)peekString:(NSUInteger)byteCount {
    return [[NSString alloc] initWithData:[_inputBuffer peek:byteCount] encoding:NSUTF8StringEncoding];
}

- (NSData *)peekBytes {
    return [_inputBuffer peek:_inputBuffer.readableElementCount];
}

- (NSString *)peekString {
    return [self peekString:_inputBuffer.readableElementCount];
}

- (NSData *)readBytes:(NSUInteger)byteCount {
    return [_inputBuffer read:byteCount];
}

- (NSString *)readString:(NSUInteger)byteCount {
    return [[NSString alloc] initWithData:[_inputBuffer read:byteCount] encoding:NSUTF8StringEncoding];
}

- (NSData *)readBytes {
    return [_inputBuffer read:_inputBuffer.readableElementCount];
}

- (NSString *)readString {
    return [self readString:_inputBuffer.readableElementCount];
}

#pragma mark Private Utility Methods

-(void) initVariables {
    if (!globalsInitialized)
    {
        //The whole reason for this following hack is for compatibility with iOS 5.0 which did not support
        //128 bit UUIDs for characteristics
        globalsInitialized = YES;
        if (![Util isAtLeastVersion:@"5.1"])
        {
            //128 bit characteristics not supported (Grab the last 4 characters)
            //This code should never be executed because we are only supporting 5.1 and high
            //It was left in in case it is needed in the future
            BRSP_INFO_UUID = @"71B2";
            BRSP_MODE_UUID = @"0A24";
            BRSP_RX_UUID = @"D159";
            BRSP_TX_UUID = @"86AF";
            BRSP_CTS_UUID = @"6AFF";
            BRSP_RTS_UUID = @"B43B";
        }
        else
        {
            //128bit is supported, use the whole string
            BRSP_INFO_UUID =        @"99564A02-DC01-4D3C-B04E-3BB1EF0571B2";
            BRSP_MODE_UUID =        @"A87988B9-694C-479C-900E-95DFA6C00A24";
            BRSP_RX_UUID =          @"BF03260C-7205-4C25-AF43-93B1C299D159";
            BRSP_TX_UUID =          @"18CDA784-4BD3-4370-85BB-BFED91EC86AF";
            BRSP_CTS_UUID =         @"0A1934F5-24B8-4F13-9842-37BB167C6AFF";
            BRSP_RTS_UUID =         @"FDD6B4D3-046D-4330-BDEC-1FD0C90CB43B";            
        }
        
        //Exclude characteristics that are not needed
        NSArray *brspServiceCharacteristics =
        [NSArray arrayWithObjects:
         [CBUUID UUIDWithString:BRSP_MODE_UUID],
         [CBUUID UUIDWithString:BRSP_RX_UUID],
         [CBUUID UUIDWithString:BRSP_TX_UUID],
         [CBUUID UUIDWithString:BRSP_INFO_UUID],
         [CBUUID UUIDWithString:BRSP_RTS_UUID],
         nil];
        
        serviceCharacteristicArrays =
        [NSDictionary dictionaryWithObjects:
         [NSArray arrayWithObjects:brspServiceCharacteristics, nil]
                                    forKeys:[NSArray arrayWithObjects:[CBUUID UUIDWithString:BRSP_SERVICE_UUID], nil]];
    }
    
    //reset member variables to default state
    _currentMode = BrspModeIdle;
    //_activePeripheral = nil;
    _serviceDiscoveryCount = 0;
    _lastRTS = 0;
    _alreadySending = NO;
//    _inputBuffer = nil;
//    _outputBuffer = nil;
    _securityLevel = 99; //Unknown security
    _isOpen = NO;
}

//Reads a charcteristic of the BRSP service
-(void) readCharacteristic:(NSString*)characteristicString ForService:(NSString*)serviceString {
    CBService *service = [Util findService:[CBUUID UUIDWithString:serviceString] InPeripheral:_activePeripheral];
    CBCharacteristic *characteristic = [Util findCharacteristic:[CBUUID UUIDWithString:characteristicString] InService:service];
    if (characteristic)
        //Prevent a request if this object isn't responding to cbPeripheralDelegate events
        if (_activePeripheral.delegate == self)
            [_activePeripheral readValueForCharacteristic:characteristic];
}

//Writes a charcteristic of the BRSP service
-(void) writeCharacteristic:(NSString*)characteristicString ForService:(NSString*)serviceString Value:(NSData*)data {
    CBService *service = [Util findService:[CBUUID UUIDWithString:serviceString] InPeripheral:_activePeripheral];
    CBCharacteristic *characteristic = [Util findCharacteristic:[CBUUID UUIDWithString:characteristicString] InService:service];
    if (characteristic)
        if (_activePeripheral.delegate == self) //Prevent a request if this object isn't responding to cbPeripheralDelegate events
            //TODO: In future have condition to check for CBCharacteristicWriteWithResponse or not
            [_activePeripheral writeValue:data forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
}

//Enables or Disables a notification for a characteristic
-(void) enableNotification:(CBUUID *)serviceUUID characteristicUUID:(CBUUID *)characteristicUUID Enabled:(BOOL)enabled {
    CBService *service = [Util findService:serviceUUID InPeripheral:_activePeripheral];
    CBCharacteristic *characteristic = [Util findCharacteristic:characteristicUUID InService:service];
    if (characteristic)
        //Prevent a request if this object isn't responding to cbPeripheralDelegate events
        if (_activePeripheral.delegate == self)
            [_activePeripheral setNotifyValue:enabled forCharacteristic:characteristic];
}

@end
