var searchData=
[
  ['writebytes_3a',['writeBytes:',['../interface_brsp.html#a350b0f594823201d219836d6333d98e6',1,'Brsp']]],
  ['writestring_3a',['writeString:',['../interface_brsp.html#a92dcaeba034656ab64a044ea1692e19e',1,'Brsp']]]
];
