var searchData=
[
  ['brspmode',['brspMode',['../interface_brsp.html#a993e89aefdfffd6f9f98cb1385f4f471',1,'Brsp']]]
];
