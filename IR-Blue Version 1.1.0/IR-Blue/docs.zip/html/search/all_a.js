var searchData=
[
  ['readbytes',['readBytes',['../interface_brsp.html#abe9cc8cfd714e633ceede2559b396586',1,'Brsp']]],
  ['readbytes_3a',['readBytes:',['../interface_brsp.html#a28db664a8fd324cb7cc2e1b558f26562',1,'Brsp']]],
  ['readstring',['readString',['../interface_brsp.html#aa430b673476267dda63e13d3ccd2255b',1,'Brsp']]],
  ['readstring_3a',['readString:',['../interface_brsp.html#a8896c9ccbf2b011cd43fcff0553ab267',1,'Brsp']]]
];
