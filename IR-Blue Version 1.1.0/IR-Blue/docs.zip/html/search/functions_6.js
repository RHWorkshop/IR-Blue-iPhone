var searchData=
[
  ['peekbytes',['peekBytes',['../interface_brsp.html#a849e525650360e98c9f7b405f01ed1c0',1,'Brsp']]],
  ['peekbytes_3a',['peekBytes:',['../interface_brsp.html#a17bc1776e63a516c338e55220dc7c421',1,'Brsp']]],
  ['peekstring',['peekString',['../interface_brsp.html#a24892232fab839db1f9dffaaad02d28a',1,'Brsp']]],
  ['peekstring_3a',['peekString:',['../interface_brsp.html#aa27b1da107cf28284f6b65f4285f07db',1,'Brsp']]]
];
