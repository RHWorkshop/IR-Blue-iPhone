var searchData=
[
  ['peripheral',['peripheral',['../interface_brsp.html#a8f690b01a02e36b7e96cba2d698f8e3c',1,'Brsp']]]
];
