var searchData=
[
  ['cbuuid_28stringextraction_29',['CBUUID(StringExtraction)',['../category_c_b_u_u_i_d_07_string_extraction_08.html',1,'']]],
  ['changebrspmode_3a',['changeBrspMode:',['../interface_brsp.html#a11512085a8774a9ca126457591110e47',1,'Brsp']]],
  ['close',['close',['../interface_brsp.html#a7aa968f276b512ecb8272fb08caa0754',1,'Brsp']]]
];
