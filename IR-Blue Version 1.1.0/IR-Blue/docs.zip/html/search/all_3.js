var searchData=
[
  ['delegate',['delegate',['../interface_brsp.html#ae52f8a429f229fcdf727bdfd55413482',1,'Brsp']]]
];
