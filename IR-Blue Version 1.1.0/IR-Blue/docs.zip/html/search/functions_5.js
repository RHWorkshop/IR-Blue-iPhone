var searchData=
[
  ['open',['open',['../interface_brsp.html#a11374a65a59a8384b35928fb3631637d',1,'Brsp']]]
];
