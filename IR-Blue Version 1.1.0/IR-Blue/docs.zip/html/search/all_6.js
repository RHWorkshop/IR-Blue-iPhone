var searchData=
[
  ['getotaupdateinstructionsfrom_3ashouldfactoryresetaftersuccess_3a',['getOTAUpdateInstructionsFrom:shouldFactoryResetAfterSuccess:',['../interface_brsp.html#a8ef36cf295dc3f6f91e1d44b5b1f93ac',1,'Brsp']]]
];
