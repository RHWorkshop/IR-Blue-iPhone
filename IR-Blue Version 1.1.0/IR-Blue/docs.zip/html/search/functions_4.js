var searchData=
[
  ['initwithperipheral_3a',['initWithPeripheral:',['../interface_brsp.html#a78d22a8e26b23a27608928646713f551',1,'Brsp']]],
  ['initwithperipheral_3ainputbuffersize_3aoutputbuffersize_3a',['initWithPeripheral:InputBufferSize:OutputBufferSize:',['../interface_brsp.html#aae9253e6c158bf344c6cf29cc02cdf9a',1,'Brsp']]]
];
