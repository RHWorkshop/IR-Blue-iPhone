var searchData=
[
  ['inputbuffercount',['inputBufferCount',['../interface_brsp.html#ae4274ae026b322f2e88e3d2d3082ea17',1,'Brsp']]],
  ['inputbuffersize',['inputBufferSize',['../interface_brsp.html#ad0f9bfce13d11b5d1390dc2f9072a19b',1,'Brsp']]],
  ['isdatamodesupported',['isDataModeSupported',['../interface_brsp.html#a788da6a275e21a4ca40cb92ed59f92c9',1,'Brsp']]],
  ['isfirmwareupdatemodesupported',['isFirmwareUpdateModeSupported',['../interface_brsp.html#ae1b46043af84dde28add56874ced2202',1,'Brsp']]],
  ['isopen',['isOpen',['../interface_brsp.html#af1f77a430a687d4862411892301767bd',1,'Brsp']]],
  ['isremotecommandmodesupported',['isRemoteCommandModeSupported',['../interface_brsp.html#a9399428180d61029be1edef7e70374ff',1,'Brsp']]],
  ['issending',['isSending',['../interface_brsp.html#ace9d5ba0fc16909a56431c3d9cec8ca1',1,'Brsp']]]
];
