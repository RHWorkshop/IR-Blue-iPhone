var searchData=
[
  ['changebrspmode_3a',['changeBrspMode:',['../interface_brsp.html#a11512085a8774a9ca126457591110e47',1,'Brsp']]],
  ['close',['close',['../interface_brsp.html#a7aa968f276b512ecb8272fb08caa0754',1,'Brsp']]]
];
