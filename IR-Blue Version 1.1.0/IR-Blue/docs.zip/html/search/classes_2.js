var searchData=
[
  ['cbuuid_28stringextraction_29',['CBUUID(StringExtraction)',['../category_c_b_u_u_i_d_07_string_extraction_08.html',1,'']]]
];
