var searchData=
[
  ['brsp',['Brsp',['../interface_brsp.html',1,'']]],
  ['brsp_3aerrorreceived_3a',['brsp:ErrorReceived:',['../protocol_brsp_delegate-p.html#abcc097461a379190920bed8030ee7bb1',1,'BrspDelegate-p']]],
  ['brsp_3aopenstatuschanged_3a',['brsp:OpenStatusChanged:',['../protocol_brsp_delegate-p.html#a597de9f776d66608dc46bd4e379d8fb2',1,'BrspDelegate-p']]],
  ['brsp_3asendingstatuschanged_3a',['brsp:SendingStatusChanged:',['../protocol_brsp_delegate-p.html#a1ef03b1a62befe5dedf02b48bd8f375e',1,'BrspDelegate-p']]],
  ['brspdatareceived_3a',['brspDataReceived:',['../protocol_brsp_delegate-p.html#a68e44ad45dd143ee4f4a533390c3108f',1,'BrspDelegate-p']]],
  ['brspdelegate_2dp',['BrspDelegate-p',['../protocol_brsp_delegate-p.html',1,'']]],
  ['brspmode',['brspMode',['../interface_brsp.html#a993e89aefdfffd6f9f98cb1385f4f471',1,'Brsp']]],
  ['brspmodechanged_3abrspmode_3a',['brspModeChanged:BRSPMode:',['../protocol_brsp_delegate-p.html#a35aea537df5c47b35eda5e7ab459863e',1,'BrspDelegate-p']]],
  ['brspserviceuuid',['brspServiceUUID',['../interface_brsp.html#afa9fc38a2f162e7460129f644c1c98c4',1,'Brsp']]]
];
